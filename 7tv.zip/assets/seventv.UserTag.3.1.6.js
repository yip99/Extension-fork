import{u as ue,a as He}from"./seventv.useChatEmotes.3.1.6.js";import{f as ce,e as Y,x as l,l as m,m as y,G as B,_ as P,r as S,aF as Xe,aG as be,u as M,O as $e,i as It,S as St,a as le,a9 as Ke,W as ht,q as O,D as k,h as te,J as vt,F as q,B as F,I as Z,aA as Et,w as ve,n as De,C as fe,t as ft,E as re,d as pt,s as Je,an as yt,P as Ae,a1 as pe,N as Q,H as We,Y as Re,ad as _t,au as Pt,az as bt,a2 as ze,M as Ot,as as xt,Q as At,R as Rt,a3 as Bt,aH as Nt}from"./seventv.index.3.1.6.js";import{d as Ye,S as Vt}from"./seventv.useCosmetics.3.1.6.js";import{t as Ft,u as X,B as Ht,j as Wt,E as Ce,h as Be,r as zt,m as Yt,k as qt,L as jt,l as Qt}from"./seventv.GearsIcon.3.1.6.js";import{l as ie,L as Gt}from"./seventv.Logger.3.1.6.js";import{f as Ne,g as Xt}from"./seventv.Transform.3.1.6.js";import{C as Ze}from"./seventv.ChatMessage.3.1.6.js";import{d as Kt,i as Jt,g as Zt}from"./seventv.index.3.1.62.js";import{d as ea}from"./seventv.Async.3.1.6.js";import{U as ta,u as aa}from"./seventv.UiConfirmPrompt.3.1.6.js";import{t as na,a as wt,b as Ct,u as Le,E as Mt,c as ra}from"./seventv.Emote.3.1.6.js";import{a as qe}from"./seventv.useModule.3.1.6.js";import{w as ee,x as sa,y as oa,G as Ee}from"./seventv.index.3.1.63.js";import{S as et}from"./seventv.StoreSubscribeButton.3.1.6.js";import{a as ia,u as la}from"./seventv.Settings.3.1.6.js";import{O as ua}from"./seventv.OpenLinkIcon.3.1.6.js";import{v as da}from"./seventv.v4.3.1.6.js";import{a as tt}from"./seventv.useFloatContext.3.1.6.js";import{R as Ve}from"./seventv.ReactHooks.3.1.6.js";import{T as ca,U as ma}from"./seventv.UiDraggable.3.1.6.js";import{U as $t}from"./seventv.UiScrollable.3.1.6.js";const at=new WeakMap;function Tt(a){let t=at.get(a);return t||(t=ce({isDarkTheme:1,primaryColorHex:null,useHighContrastColors:!0,showTimestamps:!1,showModerationIcons:!1,hovering:!1,pauseReason:new Set(["SCROLL"]),currentChannel:{},imageFormat:"WEBP",twitchBadgeSets:{},blockedUsers:new Set}),at.set(a,t)),t}const ga={ref:"tooltip",class:"seventv-tooltip","tooltip-type":"badge"},ha=Y({__name:"BadgeTooltip",props:{alt:{}},setup(a){return(t,e)=>(l(),m("div",ga,[y("p",null,B(t.alt),1)],512))}}),va=P(ha,[["__scopeId","data-v-bfbc76a7"]]),fa={class:"seventv-chat-badge"},pa=["srcset","alt"],ya=Y({__name:"Badge",props:{alt:{},type:{},badge:{}},setup(a){const t=a,e=S(""),r=S(""),n={twitch:u=>`${u.image1x} 1x, ${u.image2x} 2x, ${u.image4x} 4x`,picture:u=>`${u.profileImageURL.replace(Xe,"28x28")} 1.6x,
		${u.profileImageURL.replace(Xe,"70x70")} 3.8x`,app:u=>u.data.host.files.map((w,_)=>`https:${u.data.host.url}/${w.name} ${_+1}x`).join(", ")}[t.type](t.badge),s=S(),{show:i,hide:f}=be(va,{alt:t.alt});function g(u){return u.kind==="BADGE"&&t.type==="app"}return g(t.badge)&&(e.value=t.badge.data.backgroundColor??""),typeof t.badge=="string"&&(r.value="25%"),(u,w)=>(l(),m("div",fa,[y("img",{ref_key:"imgRef",ref:s,srcset:M(n),alt:u.alt,style:$e({backgroundColor:e.value,borderRadius:r.value}),onMouseenter:w[0]||(w[0]=_=>M(i)(s.value)),onMouseleave:w[1]||(w[1]=_=>M(f)())},null,44,pa)]))}}),Me=P(ya,[["__scopeId","data-v-ca2d1abd"]]),nt=new Map;function rt(a,t=!0){const e=t?nt.get(a)||nt.set(a,new Audio(a)).get(a):new Audio(a),r=(s=1)=>{e.volume=s,e.play()},n=()=>e.pause();return Ft(()=>{e.remove()}),{play:r,stop:n,audio:e}}const st=new WeakMap,Pe=X("highlights.custom"),_a=X("highlights.sound_volume");function ba(a){const t=Kt(),e=It(St,""),r=ce({ping:rt(e+"/sound/ping.ogg")});let n=st.get(a);n||(n=ce({highlights:{}}),le(Pe,b=>{if(n){for(const[C,p]of Object.entries(n.highlights))p.persist&&delete n.highlights[C];for(const[,C]of b)n.highlights[C.id]=C,f(C),g(C)}},{immediate:!0}),st.set(a,n));const s=ea(function(){if(!n)return;const b=Array.from(Object.values(n.highlights)).filter(C=>C.persist).map(C=>[C.id,Ke({...C,soundFile:Ke(C.soundFile),soundDef:void 0,flashTitleFn:void 0})]);Pe.value=new Map(b)},250);function i(b,C,p){if(!n)return{};const I=n.highlights[b]={...C,id:b,persist:p};return f(I),p&&(Pe.value.set(b,ht(I)),s()),I}function f(b){var I;if(!b.soundFile){(I=b.soundPath)!=null&&I.startsWith("#")&&r[b.soundPath.slice(1)]&&(b.soundDef=r[b.soundPath.slice(1)]);return}const C=new Blob([b.soundFile.data],{type:b.soundFile.type}),p=URL.createObjectURL(C);return b.soundPath=p,b.soundDef=rt(p),p}function g(b){b.flashTitleFn=b.flashTitle?()=>` 💬 Highlight: ${b.label||b.pattern}`:void 0}function u(b){n&&(delete n.highlights[b],s())}function w(b,C){var x,V,j,U;if(!n)return!1;const p=n==null?void 0:n.highlights[b];if(!p)return!1;let I=!1;if(p.phrase||!p.phrase&&!p.username&&!p.badge)if(p.regexp){let d=p.cachedRegExp;if(!d)try{d=new RegExp(p.pattern,"i"),Object.defineProperty(p,"cachedRegExp",{value:d})}catch(T){return ie.warn("<ChatHighlights>","Invalid regexp:",p.pattern??""),C.setHighlight("#878787","Error "+T.message),!1}I=d.test(C.body)}else p.pattern?I=p.caseSensitive?C.body.includes(p.pattern):C.body.toLowerCase().includes(p.pattern.toLowerCase()):typeof p.test=="function"&&(I=p.test(C));else p.username?I=((x=C.author)==null?void 0:x.displayName.toLowerCase())===((V=p.pattern)==null?void 0:V.toLowerCase()):p.badge&&(I=Object.keys(C.badges).indexOf(((j=p.pattern)==null?void 0:j.toLowerCase())??"")>-1&&Object.values(C.badges).indexOf(((U=p.version)==null?void 0:U.toLowerCase())??"")>-1);return I&&(C.setHighlight(p.color,p.label),p.soundDef&&!C.historical&&p.soundDef.play(_a.value/100),p.flashTitleFn&&!C.historical&&o(p,C)),I}const _=S(""),c=S(document.title);let v=0;const h=Ht(()=>{Jt(v++%2===0?_.value:c.value)},1e3,{immediate:!1,immediateCallback:!0});function o(b,C){!b.flashTitleFn||h.isActive.value||(c.value=document.title,_.value=b.flashTitleFn(C),h.resume(),Wt(t).toBe("visible").then(()=>{h.pause(),_.value="",document.title=c.value}))}function $(){return n?Ce(n.highlights):{}}function L(){if(!n)return{};const b=Object.fromEntries(Object.entries(n.highlights).filter(([,C])=>C.phrase===!0||!C.phrase&&!C.username&&!C.badge));return Ce(b)}function R(){if(!n)return{};const b=Object.fromEntries(Object.entries(n.highlights).filter(([,C])=>C.username===!0));return Ce(b)}function H(){if(!n)return{};const b=Object.fromEntries(Object.entries(n.highlights).filter(([,C])=>C.badge===!0));return Ce(b)}function N(b,C){if(!n)return;const p=n.highlights[b];p&&(n.highlights[C]=p,delete n.highlights[b],p.id=C,s())}return{define:i,remove:u,getAll:$,getAllPhraseHighlights:L,getAllUsernameHighlights:R,getAllBadgeHighlights:H,save:s,updateId:N,checkMatch:w,updateSoundData:f,updateFlashTitle:g}}const ot=new WeakMap;function Ie(a){let t=ot.get(a);t||(t=ce({TWITCH:{onShowViewerCard:()=>{},onShowViewerWarnPopover:()=>{}},YOUTUBE:{},KICK:{},UNKNOWN:{}}),ot.set(a,t));function e(s,i,f){t&&(t[s][i]=f)}function r(s,i,f){if(!t||!s||!s.currentTarget||!i)return!1;const g=s.currentTarget.getBoundingClientRect();return t[a.platform].onShowViewerCard(i,0,f,g.bottom),!0}function n(s,i,f){return!t||!s||!i?!1:(t[a.platform].onShowViewerWarnPopover(s,i,f),!0)}return{update:e,openViewerCard:r,openViewerWarnPopover:n}}const wa=ee`
	query ViewerCard(
		$channelID: ID!
		$channelIDStr: String!
		$channelLogin: String!
		$targetLogin: String!
		$isViewerBadgeCollectionEnabled: Boolean!
	) {
		activeTargetUser: user(login: $targetLogin) {
			id
		}
		targetUser: user(login: $targetLogin, lookupType: ALL) {
			id
			login
			bannerImageURL
			displayName
			displayBadges(channelID: $channelID) {
				...badge
				description
			}
			chatColor
			profileImageURL(width: 70)
			createdAt
			relationship(targetUserID: $channelID) {
				cumulativeTenure: subscriptionTenure(tenureMethod: CUMULATIVE) {
					months
					daysRemaining
				}
				followedAt
				subscriptionBenefit {
					id
					tier
					purchasedWithPrime
					gift {
						isGift
					}
				}
			}
			isModerator(channelID: $channelIDStr)
			stream {
				id
				game {
					id
					displayName
				}
				viewersCount
			}
		}
		channelUser: user(login: $channelLogin) {
			id
			login
			displayName
			subscriptionProducts {
				...subProduct
			}
			self {
				banStatus {
					isPermanent
				}
				isModerator
			}
		}
		currentUser {
			login
			id
		}
		channelViewer(userLogin: $targetLogin, channelLogin: $channelLogin) {
			id
			earnedBadges @include(if: $isViewerBadgeCollectionEnabled) {
				...badge
				description
			}
		}
		channel(id: $channelID) {
			id
			moderationSettings {
				canAccessViewerCardModLogs
			}
		}
	}

	${na}
	${wt}
`,Ca=ee`
	query ViewerCardModLogs($channelLogin: String!, $channelID: ID!, $targetID: ID!) {
		targetUser: user(id: $targetID) {
			id
			login
		}
		channelUser: user(login: $channelLogin) {
			id
			login
		}
		currentUser {
			login
			id
		}
		banStatus: chatRoomBanStatus(channelID: $channelID, userID: $targetID) {
			bannedUser {
				id
				login
				displayName
			}
			createdAt
			expiresAt
			isPermanent
			moderator {
				id
				login
				displayName
			}
			reason
		}

		viewerCardModLogs(channelID: $channelID, targetID: $targetID) {
			messages: messages(first: 1000) {
				... on ViewerCardModLogsMessagesError {
					code
				}
				... on ViewerCardModLogsMessagesConnection {
					pageInfo {
						hasNextPage
					}
					count
				}
			}
			bans: targetedActions(first: 99, type: BAN) {
				...modLogsTargetedActionsResultFragment
			}
			timeouts: targetedActions(first: 99, type: TIMEOUT) {
				...modLogsTargetedActionsResultFragment
			}
			unbans: targetedActions(first: 99, type: UNBAN) {
				...modLogsTargetedActionsResultFragment
			}
			untimeouts: targetedActions(first: 99, type: UNTIMEOUT) {
				...modLogsTargetedActionsResultFragment
			}
			warnings: targetedActions(first: 99, type: WARN) {
				...modLogsTargetedActionsResultFragment
			}
			comments(first: 100) {
				... on ModLogsCommentConnection {
					edges {
						cursor
						node {
							id
							timestamp
							text
							channel {
								id
							}
							author {
								id
								login
								displayName
								chatColor
							}
						}
					}
					pageInfo {
						hasNextPage
						hasPreviousPage
					}
				}
				... on ModLogsCommentsError {
					code
				}
				__typename
			}
		}
	}

	fragment modLogsTargetedActionsResultFragment on ModLogsTargetedActionsResult {
		__typename
		... on ModLogsTargetedActionsError {
			code
		}
		... on ModLogsTargetedActionsConnection {
			count
			pageInfo {
				hasNextPage
			}
			edges {
				cursor
				node {
					...modLogsTargetedActionFragment
				}
			}
		}
	}

	fragment modLogsTargetedActionFragment on ModLogsTargetedAction {
		id
		localizedLabel {
			fallbackString
			...modActionTokens
		}
		timestamp
		type
	}

	fragment modActionTokens on ModActionsLocalizedText {
		localizedStringFragments {
			...modActionText
		}
	}

	fragment modActionText on ModActionsLocalizedTextFragment {
		token {
			... on ModActionsLocalizedTextToken {
				text
			}
			... on User {
				displayName
				login
				id
			}
		}
	}
`,Ma=ee`
	#import "twilight/features/message/fragments/message-sender/sender-fragment.gql"
	#import "twilight/features/moderation/moderation-actions/hooks/use-get-mod-actions/mod-action-tokens-fragment.gql"
	query ViewerCardModLogsMessagesBySender($channelID: ID!, $senderID: ID!, $cursor: Cursor) {
		logs: viewerCardModLogs(channelID: $channelID, targetID: $senderID) {
			messages(first: 50, after: $cursor) {
				... on ViewerCardModLogsMessagesError {
					code
				}
				... on ViewerCardModLogsMessagesConnection {
					edges {
						...viewerCardModLogsMessagesEdgeFragment
					}
					pageInfo {
						hasNextPage
					}
				}
			}
		}
	}
	fragment viewerCardModLogsMessagesEdgeFragment on ViewerCardModLogsMessagesEdge {
		__typename
		node {
			...viewerCardModLogsCaughtMessageFragment
			...viewerCardModLogsChatMessageFragment
			...viewerCardModLogsModActionsMessageFragment
		}
		cursor
	}
	fragment viewerCardModLogsChatMessageFragment on ViewerCardModLogsChatMessage {
		id
		sender {
			id
			login
			chatColor
			displayName
			displayBadges(channelID: $channelID) {
				id
				setID
				version
				__typename
			}
			__typename
		}
		sentAt
		content {
			text
			fragments {
				text
				content {
					... on Emote {
						emoteID: id
						setID
						token
					}
					#mention
					... on User {
						id
					}
					__typename
				}
			}
			__typename
		}
	}
	fragment viewerCardModLogsCaughtMessageFragment on ViewerCardModLogsCaughtMessage {
		id
		status
		category
		sentAt
		resolvedAt
		content {
			text
			fragments {
				text
				content {
					... on Emote {
						emoteID: id
						setID
						token
					}
					... on User {
						id
					}
					__typename
				}
			}
			__typename
		}
		sender {
			id
			login
			chatColor
			displayName
			displayBadges(channelID: $channelID) {
				id
				setID
				version
			}
			__typename
		}
		resolver {
			...sender
		}
		__typename
	}

	fragment viewerCardModLogsModActionsMessageFragment on ViewerCardModLogsModActionsMessage {
		timestamp
		content {
			fallbackString
			...modActionTokens
		}
	}

	fragment modActionTokens on ModActionsLocalizedText {
		localizedStringFragments {
			...modActionText
		}
	}

	fragment modActionText on ModActionsLocalizedTextFragment {
		token {
			... on ModActionsLocalizedTextToken {
				text
			}
			... on User {
				displayName
				login
				id
			}
		}
	}

	fragment sender on User {
		id
		login
		displayName
		chatColor
		displayBadges {
			...badge
		}
	}

	${wt}
`,$a=ee`
	mutation createModComment($input: CreateModeratorCommentInput!) {
		createModeratorComment(input: $input) {
			comment {
				...modComment
			}
		}
	}

	${Ct}
`;ee`
	mutation deleteModeratorComment($input: DeleteModeratorCommentInput!) {
		deleteModeratorComment(input: $input) {
			comment {
				...modComment
			}
		}
	}

	${Ct}
`;const Ta={},ka={xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 448 512",fill:"currentColor"},Ua=y("path",{d:"M224 0c-17.7 0-32 14.3-32 32V51.2C119 66 64 130.6 64 208v18.8c0 47-17.3 92.4-48.5 127.6l-7.4 8.3c-8.4 9.4-10.4 22.9-5.3 34.4S19.4 416 32 416H416c12.6 0 24-7.4 29.2-18.9s3.1-25-5.3-34.4l-7.4-8.3C401.3 319.2 384 273.9 384 226.8V208c0-77.4-55-142-128-156.8V32c0-17.7-14.3-32-32-32zm45.3 493.3c12-12 18.7-28.3 18.7-45.3H224 160c0 17 6.7 33.3 18.7 45.3s28.3 18.7 45.3 18.7s33.3-6.7 45.3-18.7z"},null,-1),Da=[Ua];function La(a,t){return l(),m("svg",ka,Da)}const Ia=P(Ta,[["render",La]]),Sa={},Ea={xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 640 512",fill:"currentColor"},Pa=y("path",{d:"M38.8 5.1C28.4-3.1 13.3-1.2 5.1 9.2S-1.2 34.7 9.2 42.9l592 464c10.4 8.2 25.5 6.3 33.7-4.1s6.3-25.5-4.1-33.7l-90.2-70.7c.2-.4 .4-.9 .6-1.3c5.2-11.5 3.1-25-5.3-34.4l-7.4-8.3C497.3 319.2 480 273.9 480 226.8V208c0-77.4-55-142-128-156.8V32c0-17.7-14.3-32-32-32s-32 14.3-32 32V51.2c-42.6 8.6-79 34.2-102 69.3L38.8 5.1zM406.2 416L160 222.1v4.8c0 47-17.3 92.4-48.5 127.6l-7.4 8.3c-8.4 9.4-10.4 22.9-5.3 34.4S115.4 416 128 416H406.2zm-40.9 77.3c12-12 18.7-28.3 18.7-45.3H320 256c0 17 6.7 33.3 18.7 45.3s28.3 18.7 45.3 18.7s33.3-6.7 45.3-18.7z"},null,-1),Oa=[Pa];function xa(a,t){return l(),m("svg",Ea,Oa)}const Aa=P(Sa,[["render",xa]]),Ra={},Ba={xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 448 512",width:"1em",height:"1em",fill:"currentColor"},Na=y("path",{d:"M96 0L63.9 44.9C58.8 52.1 56 60.8 56 69.6V72c0 22.1 17.9 40 40 40s40-17.9 40-40V69.6c0-8.8-2.8-17.5-7.9-24.6L96 0zM224 0L191.9 44.9c-5.1 7.2-7.9 15.8-7.9 24.6V72c0 22.1 17.9 40 40 40s40-17.9 40-40V69.6c0-8.8-2.8-17.5-7.9-24.6L224 0zm95.9 44.9c-5.1 7.2-7.9 15.8-7.9 24.6V72c0 22.1 17.9 40 40 40s40-17.9 40-40V69.6c0-8.8-2.8-17.5-7.9-24.6L352 0 319.9 44.9zM128 176V144H64v32 48H0V350.8l29.2 15.3 60-28.6 7.1-3.4 7 3.5L160 366.1l56.8-28.4 7.2-3.6 7.2 3.6L288 366.1l56.8-28.4 7-3.5 7 3.4 60 28.6L448 350.8V224H384V176 144H320v32 48H256V176 144H192v32 48H128V176zM448 386.9l-21.3 11.2-7.1 3.7-7.2-3.4-60.2-28.6-57 28.5-7.2 3.6-7.2-3.6L224 369.9l-56.8 28.4-7.2 3.6-7.2-3.6-57-28.5L35.7 398.4l-7.2 3.4-7.1-3.7L0 386.9V512H448V386.9z"},null,-1),Va=[Na];function Fa(a,t){return l(),m("svg",Ba,Va)}const Ha=P(Ra,[["render",Fa]]),Wa={},za={xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512",width:"1em",height:"1em",fill:"currentColor"},Ya=y("path",{d:"M39.8 263.8L64 288 256 480 448 288l24.2-24.2c25.5-25.5 39.8-60 39.8-96C512 92.8 451.2 32 376.2 32c-36 0-70.5 14.3-96 39.8L256 96 231.8 71.8c-25.5-25.5-60-39.8-96-39.8C60.8 32 0 92.8 0 167.8c0 36 14.3 70.5 39.8 96z"},null,-1),qa=[Ya];function ja(a,t){return l(),m("svg",za,qa)}const Qa=P(Wa,[["render",ja]]),Ga={},Xa={class:"seventv-user-card-actions"};function Ka(a,t){return l(),m("div",Xa)}const Ja=P(Ga,[["render",Ka],["__scopeId","data-v-ac215262"]]);function bl(a){return a.kind==="TEXT"}function Za(a){return a.kind==="LINK"}function en(a){return a.kind==="EMOTE"}function tn(a){return a.kind==="MENTION"}const an=ee`
	mutation Chat_BanUserFromChatRoom($input: BanUserFromChatRoomInput!) {
		banUserFromChatRoom(input: $input) {
			ban {
				bannedUser {
					id
					login
					displayName
				}
				createdAt
				expiresAt
				isPermanent
				moderator {
					id
					login
					displayName
				}
				reason
			}
			error {
				code
				minTimeoutDurationSeconds
				maxTimeoutDurationSeconds
			}
		}
	}
`,nn=ee`
	mutation Chat_UnbanUserFromChatRoom($input: UnbanUserFromChatRoomInput!) {
		unbanUserFromChatRoom(input: $input) {
			ban {
				bannedUser {
					id
					login
					displayName
				}
				createdAt
				expiresAt
				isPermanent
				moderator {
					id
					login
					displayName
				}
			}
			error {
				code
			}
		}
	}
`,rn=ee`
	mutation Chat_DeleteChatMessage($input: DeleteChatMessageInput!) {
		deleteChatMessage(input: $input) {
			responseCode
			message {
				id
				sender {
					id
					login
					displayName
				}
				content {
					text
				}
			}
		}
	}
`,sn=ee`
	mutation PinChatMessage($input: PinChatMessageInput!) {
		pinChatMessage(input: $input) {
			pinnedChatMessage {
				id
				pinnedMessage {
					id
				}
			}
			error {
				code
			}
		}
	}
`,on=ee`
	mutation ModUser($input: ModUserInput!) {
		result: modUser(input: $input) {
			channel {
				id
				login
			}
			target {
				id
				login
			}
			error {
				code
			}
		}
	}
`,ln=ee`
	mutation UnmodUser($input: UnmodUserInput!) {
		result: unmodUser(input: $input) {
			channel {
				id
				login
			}
			target {
				id
				login
			}
			error {
				code
			}
		}
	}
`;function je(a,t){const e=Le();function r(g,u){return e.value?e.value.mutate({mutation:an,variables:{input:{channelID:a.id,bannedUserLogin:t,expiresIn:g,reason:u}}}):Promise.reject("Missing Apollo")}function n(){return e.value?e.value.mutate({mutation:nn,variables:{input:{channelID:a.id,bannedUserLogin:t}}}):Promise.reject("Missing Apollo")}function s(g,u){return e.value?e.value.mutate({mutation:sn,variables:{input:{channelID:a.id,messageID:g,durationSeconds:u,type:"MOD"}}}):Promise.reject("Missing Apollo")}function i(g,u){return e.value?e.value.mutate({mutation:u?ln:on,variables:{input:{channelID:a.id,targetID:g}}}):Promise.reject("Missing Apollo")}function f(g){return e.value?e.value.mutate({mutation:rn,variables:{input:{channelID:a.id,messageID:g}}}):Promise.reject("Missing Apollo")}return{banUserFromChat:r,unbanUserFromChat:n,pinChatMessage:s,deleteChatMessage:f,setUserModerator:i}}const un={},dn={width:"1em",height:"1em",version:"1.1",viewBox:"0 0 20 20",x:"0px",y:"0px",fill:"currentColor"},cn=y("g",null,[y("path",{"fill-rule":"evenodd",d:"M2 10a8 8 0 1116 0 8 8 0 01-16 0zm8 6a6 6 0 01-4.904-9.458l8.362 8.362A5.972 5.972 0 0110 16zm4.878-2.505a6 6 0 00-8.372-8.372l8.372 8.372z","clip-rule":"evenodd"})],-1),mn=[cn];function gn(a,t){return l(),m("svg",dn,mn)}const hn=P(un,[["render",gn]]),vn={},fn={width:"1em",height:"1em",version:"1.1",viewBox:"0 0 20 20",x:"0px",y:"0px",fill:"currentColor"},pn=y("g",null,[y("path",{d:"M12 2H8v1H3v2h14V3h-5V2zM4 7v9a2 2 0 002 2h8a2 2 0 002-2V7h-2v9H6V7H4z"}),y("path",{d:"M11 7H9v7h2V7z"})],-1),yn=[pn];function _n(a,t){return l(),m("svg",fn,yn)}const bn=P(vn,[["render",_n]]),wn={},Cn={width:"1em",height:"1em",version:"1.1",viewBox:"0 0 20 20",x:"0px",y:"0px",fill:"currentColor"},Mn=y("g",null,[y("path",{d:"M11 9.586V6H9v4.414l2.293 2.293 1.414-1.414L11 9.586z"}),y("path",{"fill-rule":"evenodd",d:"M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-2 0a6 6 0 11-12 0 6 6 0 0112 0z","clip-rule":"evenodd"})],-1),$n=[Mn];function Tn(a,t){return l(),m("svg",Cn,$n)}const kn=P(wn,[["render",Tn]]),Un={},Dn={width:"1em",height:"1em",version:"1.1",viewBox:"0 0 20 20",x:"0px",y:"0px",fill:"currentColor"},Ln=y("g",null,[y("path",{"fill-rule":"evenodd",d:"M10.954 3.543c-.422-.724-1.486-.724-1.908 0l-6.9 11.844c-.418.719.11 1.613.955 1.613h13.798c.844 0 1.373-.894.955-1.613l-6.9-11.844zM11 15H9v-2h2v2zm0-3H9V7h2v5z","clip-rule":"evenodd"})],-1),In=[Ln];function Sn(a,t){return l(),m("svg",Dn,In)}const En=P(Un,[["render",Sn]]),Pn={class:"seventv-chat-mod-buttons"},On=Y({__name:"ModIcons",props:{msg:{}},setup(a){var o,$,L,R,H;const t=a,e=ue(),r=Ie(e),{banUserFromChat:n,deleteChatMessage:s}=je(e,((o=t.msg.author)==null?void 0:o.username)??"");function i(){t.msg.author&&r.openViewerWarnPopover(t.msg.author.id,t.msg.author.username,0)}const f=S(),g=be(`Ban ${(($=t.msg.author)==null?void 0:$.username)??"???"}`),u=S(),w=be(`Timeout ${((L=t.msg.author)==null?void 0:L.username)??"???"}`),_=S(),c=be(`Warn ${((R=t.msg.author)==null?void 0:R.username)??"???"}`),v=S(),h=be(`Delete message by ${((H=t.msg.author)==null?void 0:H.username)??"???"}`);return(N,b)=>(l(),m("span",Pn,[N.msg.author&&!N.msg.author.isActor?(l(),m("span",{key:0,ref_key:"banRef",ref:f,onClick:b[0]||(b[0]=C=>M(n)(null)),onMouseenter:b[1]||(b[1]=C=>M(g).show(f.value)),onMouseleave:b[2]||(b[2]=C=>M(g).hide())},[O(hn)],544)):k("",!0),N.msg.author&&!N.msg.author.isActor?(l(),m("span",{key:1,ref_key:"timeoutRef",ref:u,onClick:b[3]||(b[3]=C=>M(n)("10m")),onMouseenter:b[4]||(b[4]=C=>M(w).show(u.value)),onMouseleave:b[5]||(b[5]=C=>M(w).hide())},[O(kn)],544)):k("",!0),N.msg.author&&!N.msg.author.isActor?(l(),m("span",{key:2,ref_key:"warnRef",ref:_,onClick:b[6]||(b[6]=C=>i()),onMouseenter:b[7]||(b[7]=C=>M(c).show(_.value)),onMouseleave:b[8]||(b[8]=C=>M(c).hide())},[O(En)],544)):k("",!0),y("span",{ref_key:"deleteRef",ref:v,onClick:b[9]||(b[9]=C=>M(s)(N.msg.id)),onMouseenter:b[10]||(b[10]=C=>M(h).show(v.value)),onMouseleave:b[11]||(b[11]=C=>M(h).hide())},[O(bn)],544)]))}}),xn=P(On,[["__scopeId","data-v-743de9d0"]]),Oe=Gt.Get();function An(a){const t=sa(oa,{errorPolicy:"all"}),e=ue(),r=He(e),n=ia();a||le(()=>e.user,c=>{var v,h;c&&(a=(h=(v=c.connections)==null?void 0:v.find(o=>o.platform===e.platform))==null?void 0:h.emote_set_id)},{immediate:!0});const s=te(()=>{if(a&&r.sets[a])return r.sets[a]}),i=te(()=>{var c;return n.user?e.id==n.platformUserID||(((c=e.user)==null?void 0:c.editors)??[]).some(v=>{var h;return v.id==((h=n.user)==null?void 0:h.id)})?!0:n.editAnySet:!1}),f=te(()=>n.token?i.value:!1),g=te(()=>i.value&&!n.token);async function u(c,v){var o;if(!a){Oe.error("No set ID found");return}const h=await t.mutate({action:"ADD",emote_id:c,id:a,name:v});if((o=h==null?void 0:h.errors)!=null&&o.length){const $=h.errors[0];throw new Ee($.message,$)}return h}async function w(c){var h;if(!a){Oe.error("No set ID found");return}const v=await t.mutate({action:"REMOVE",emote_id:c,id:a});if((h=v==null?void 0:v.errors)!=null&&h.length){const o=v.errors[0];throw new Ee(o.message,o)}return v}async function _(c,v){var o;if(!a){Oe.error("No set ID found");return}const h=await t.mutate({action:"UPDATE",emote_id:c,id:a,name:v});if((o=h==null?void 0:h.errors)!=null&&o.length){const $=h.errors[0];throw new Ee($.message,$)}return h}return ce({add:u,remove:w,rename:_,set:s,setID:a,canEditSet:f,needsLogin:g})}const Rn=["shrink"],Bn=["value","active","placeholder"],Nn=Y({__name:"EmoteAliasButton",props:{alias:{}},emits:["update:alias"],setup(a,{emit:t}){const e=t,r=S(!1),n=S();return(s,i)=>(l(),m("div",{class:"alias-button",shrink:!r.value},[y("input",{ref_key:"aliasRef",ref:n,value:s.alias,active:r.value,placeholder:r.value?"Alias":"...",onInput:i[0]||(i[0]=f=>e("update:alias",n.value.value)),onFocus:i[1]||(i[1]=f=>r.value=!0),onBlur:i[2]||(i[2]=f=>{s.alias===""&&(r.value=!1)})},null,40,Bn)],8,Rn))}}),Vn=P(Nn,[["__scopeId","data-v-1cf40ae2"]]),Fn={class:"emote-link-embed"},Hn=["blurred"],Wn={class:"emote-preview"},zn={class:"description"},Yn=["title"],qn={key:0,class:"emote-owner"},jn=["type"],Qn={key:0,class:"login-required"},Gn=Y({__name:"EmoteLinkEmbed",props:{emoteId:{}},setup(a){const t=a,e=`https://7tv.app/emotes/${t.emoteId}`,r=S(),n=S(""),s=S(!0),i=An(),f=la(),g=te(()=>{var h;return!!((h=i.set)!=null&&h.emotes.find(o=>o.id===t.emoteId))}),u={ADD:"add",REMOVE:"remove",CONFLICT:"conflict",LINK:"link"};async function w(){switch(c.value){case u.ADD:await i.add(t.emoteId,n.value!==""?n.value:void 0),n.value="";break;case u.REMOVE:await i.remove(t.emoteId);break;case u.CONFLICT:break;case u.LINK:window.open(e,"_blank");break}}const _=h=>(h.preventDefault(),f.open=!0,f.switchView("profile"),!1),c=te(()=>{var o;return!i.canEditSet||!r.value?u.LINK:g.value?u.REMOVE:((o=i.set)==null?void 0:o.emotes.find($=>{var L;return $.name===(n.value!==""?n.value:(L=r.value)==null?void 0:L.name)}))||n.value!==""&&!Et.test(n.value)?u.CONFLICT:u.ADD});async function v(){const h=await fetch(`https://7tv.io/v3/emotes/${t.emoteId}`);if(!h.ok)return;const o=await h.json();o.lifecycle!==2&&(r.value={id:o.id,name:o.name,data:o},o.listed!==!1&&(s.value=!1))}return vt(v),(h,o)=>{var $,L;return l(),m(q,null,[y("div",Fn,[y("div",{class:"emote-link-container",blurred:s.value},[($=r.value)!=null&&$.data?(l(),m(q,{key:0},[y("a",{href:e,target:"_blank",class:"link"},[y("div",Wn,[r.value?(l(),F(Mt,{key:0,emote:r.value},null,8,["emote"])):k("",!0)])]),y("div",zn,[y("p",{class:"emote-name",title:r.value.name},B(r.value.name),9,Yn),r.value.data.owner?(l(),m("p",qn,B(r.value.data.owner.display_name),1)):k("",!0)]),c.value===u.ADD||c.value===u.CONFLICT?(l(),F(Vn,{key:0,class:"alias-button",type:c.value,alias:n.value,"onUpdate:alias":o[0]||(o[0]=R=>n.value=R)},null,8,["type","alias"])):k("",!0),y("div",{class:"action-button",type:c.value,onClick:w},[c.value===u.LINK?(l(),F(ua,{key:0})):c.value===u.REMOVE?(l(),m(q,{key:1},[Z(" - ")],64)):(l(),m(q,{key:2},[Z(" + ")],64))],8,jn)],64)):k("",!0)],8,Hn),(L=r.value)!=null&&L.data&&s.value?(l(),m("div",{key:0,class:"emote-unlisted-warning",onClick:o[1]||(o[1]=R=>s.value=!1)}," Emote is unlisted! Click to view. ")):k("",!0)]),M(i).needsLogin?(l(),m("div",Qn,[y("a",{href:"#",onClick:_}," Authenticate extension to manage emotes ")])):k("",!0)],64)}}}),Xn=P(Gn,[["__scopeId","data-v-3c067032"]]),Kn=["href"],Jn=Y({__name:"MessageTokenLink",props:{token:{}},setup(a){return(t,e)=>(l(),m("a",{href:t.token.content.url,target:"_blank",class:"link-part"},B(t.token.content.displayText),9,Kn))}}),Zn={class:"mention-token"},er=Y({__name:"MessageTokenMention",props:{token:{},msg:{}},setup(a){const t=a,e=t.token.content.displayText.charAt(0)==="@",r=e?t.token.content.displayText.slice(1):t.token.content.displayText;return(n,s)=>(l(),m("span",Zn,[O(we,{user:n.token.content.user??{id:M(da)(),username:M(r).toLowerCase(),displayName:M(r),color:""},"is-mention":"","hide-at":!e,"hide-badges":""},null,8,["user","hide-at"])]))}}),tr=P(er,[["__scopeId","data-v-20ced684"]]),ar={class:"seventv-chat-message-rich-embed"},nr=["href"],rr={class:"seventv-chat-message-rich-embed-layout"},sr={class:"seventv-chat-message-rich-embed-layout-thumbnail"},or=["src"],ir={class:"seventv-chat-message-rich-embed-layout-description"},lr={class:"seventv-chat-message-rich-embed-layout-description-title"},ur={key:0},dr={class:"seventv-chat-message-rich-embed-layout-description-author"},cr=Y({__name:"RichEmbed",props:{richEmbed:{}},setup(a){return(t,e)=>(l(),m("div",ar,[y("a",{href:t.richEmbed.request_url,target:"_blank",class:"seventv-chat-message-rich-embed-link"},[y("div",rr,[y("div",sr,[y("img",{src:t.richEmbed.thumbnail_url,alt:"thumbnail"},null,8,or)]),y("div",ir,[y("div",null,[y("p",lr,B(t.richEmbed.title),1)]),t.richEmbed.twitch_metadata.clip_metadata.id?(l(),m("div",ur,[y("p",dr," Clipped by "+B(t.richEmbed.author_name),1)])):k("",!0)])])],8,nr)]))}}),mr=P(cr,[["__scopeId","data-v-250b0388"]]),gr=ee`
	query ChatReplies($messageID: ID!, $channelID: ID!) {
		message(id: $messageID) {
			...messageFields
			replies {
				nodes {
					...messageFields
				}
				totalCount
			}
		}
	}

	${ra}
`,hr={},vr={fill:"currenColor",width:"1em",height:"1em",version:"1.1",viewBox:"0 0 16 16",x:"0px",y:"0px"},fr=y("g",null,[y("path",{d:"M5 6H7V8H5V6Z"}),y("path",{d:"M9 6H11V8H9V6Z"}),y("path",{"fill-rule":"evenodd","clip-rule":"evenodd",d:"M8 14L10 12H13C13.5523 12 14 11.5523 14 11V3C14 2.44772 13.5523 2 13 2H3C2.44772 2 2 2.44772 2 3V11C2 11.5523 2.44772 12 3 12H6L8 14ZM6.82843 10H4V4H12V10H9.17157L8 11.1716L6.82843 10Z"})],-1),pr=[fr];function yr(a,t){return l(),m("svg",vr,pr)}const Qe=P(hr,[["render",yr]]),_r={},br={width:"1em",height:"1em",version:"1.1",viewBox:"0 0 20 20",x:"0px",y:"0px"},wr=y("path",{d:"M8.5 5.5L7 4L2 9L7 14L8.5 12.5L6 10H10C12.2091 10 14 11.7909 14 14V16H16V14C16 10.6863 13.3137 8 10 8H6L8.5 5.5Z"},null,-1),Cr=[wr];function Mr(a,t){return l(),m("svg",br,Cr)}const $r=P(_r,[["render",Mr]]),Tr={class:"seventv-tray-header"},kr={class:"seventv-tray-icon seventv-reply"},Ur={class:"seventv-tray-header-text"},Dr={key:0},Lr={key:1},Ir={class:"seventv-tray-user-message-container"},Sr=Y({__name:"ReplyTray",props:{close:{type:Function},id:{},authorID:{},username:{},displayName:{},body:{},deleted:{type:Boolean},thread:{}},setup(a){const t=a,e=S(null),r=S([]),n=S([]),s=ue(),i=He(s),f=Le();return ve(async()=>{var w;if(!f.value)return;const g=await f.value.query({query:gr,fetchPolicy:"no-cache",variables:{messageID:((w=t.thread)==null?void 0:w.id)??t.id,channelID:s.id}}).catch(_=>{ie.error("failed to fetch chat replies",_.message)});if(!g||!g.data||!g.data.message)return;e.value=Ne(g.data.message);const u=[e.value,...g.data.message.replies.nodes.map(_=>Ne(_))];u.forEach(_=>{_.parent={author:{displayName:t.displayName??"",username:t.username??""},body:t.body,deleted:t.deleted,id:t.id,uid:t.authorID??"",thread:t.thread??null}}),n.value=u}),ve(()=>{const g=n.value.findIndex(w=>w.id===t.id),u=r.value.at(g);u&&De(()=>u.scrollIntoView())}),(g,u)=>(l(),m(q,null,[y("div",Tr,[y("div",kr,[n.value.length<=1?(l(),F($r,{key:0})):(l(),F(Qe,{key:1}))]),y("div",Ur,[n.value.length<=1&&g.authorID?(l(),m("span",Dr,B(`Replying to @${g.displayName??g.username}:`),1)):(l(),m("span",Lr," Thread "))]),y("div",{class:"seventv-tray-icon seventv-close",onClick:u[0]||(u[0]=w=>g.close())},[O(ca)])]),O($t,null,{default:fe(()=>[y("div",Ir,[(l(!0),m(q,null,re(n.value,w=>{var _;return l(),m("div",{key:w.id,ref_for:!0,ref_key:"msgElems",ref:r,class:"seventv-tray-user-message"},[O(Fe,{msg:w,emotes:M(i).active,"force-timestamp":!0,as:"Reply",class:ft(["thread-msg",{"is-root-msg":((_=e.value)==null?void 0:_.id)===w.id,"is-selected-msg":t.id===w.id&&n.value.length>1}])},null,8,["msg","emotes","class"])])}),128))])]),_:1})],64))}}),Er=P(Sr,[["__scopeId","data-v-10eb02d7"]]),it=pt(new Set);function lt(a,t){const e=pt({current:null}),r={parent:e,component:ht(a),props:t},n=le(e,s=>{s.current?it.add(r):(it.delete(r),n())});return{$$typeof:Ve,key:null,ref:e,type:"seventv-tray-container",props:{}}}function Pr(a){const t=a;return!!(t.id&&t.body)&&typeof t.deleted=="boolean"}function Or(a){var t;return{body:Er,inputValueOverride:"",sendButtonOverride:"reply",disableBits:!0,disablePaidPinnedChat:!0,disableChat:a.deleted||((t=a.thread)==null?void 0:t.deleted),sendMessageHandler:{type:"reply",additionalMetadata:{reply:{parentMsgId:a.id,parentMessageBody:a.body,...a.authorID?{parentUid:a.authorID,parentUserLogin:a.username,parentDisplayName:a.displayName}:{},...a.thread?{threadParentMsgId:a.thread.id,threadParentDeleted:a.thread.deleted,threadParentUserLogin:a.thread.login}:{}}}},type:"reply"}}function xr(a,t){let e=null;switch(a){case"Reply":if(!Pr(t))break;e=Or(t)}return e}function Ar(a,t,e,r=!1){const n=qe("chat-input"),s=r?"setModifierTray":"setTray";function i(){var g;!n.value||typeof((g=n.value.instance)==null?void 0:g[s])!="function"||n.value.instance[s](null)}function f(){var _;if(!n.value||typeof((_=n.value.instance)==null?void 0:_[s])!="function")return;const g=S(!0),u={...t==null?void 0:t(),close:()=>{g.value=!1,i()}};if(!u)return g.value=!1,g;const w=e??xr(a,u);return w?(n.value.instance[s]({...w,header:w.header?lt(w.header,u):void 0,body:w.body?lt(w.body,u):void 0}),g):(g.value=!1,g)}return{open:f,clear:i,props:t,options:e}}function wl(a,t=!1){const e=Je(null),r=Je(null),i={type:"seventv-custom-tray",header:{$$typeof:Ve,key:"header",ref:c=>e.value=c,type:"seventv-tray-container-header",props:{}},body:{$$typeof:Ve,key:"body",ref:c=>r.value=c,type:"seventv-tray-container-body",props:{}},sendMessageHandler:a.messageHandler?{type:"custom-message-handler",handleMessage:a.messageHandler}:a.sendMessageHandler??void 0},f=t?"setModifierTray":"setTray",g=qe("chat-input");function u(c){var v;!((v=g.value)!=null&&v.instance)||typeof g.value.instance[f]!="function"||g.value.instance[f](c)}return ce({open:()=>u({...a,...i}),close:()=>u(),bodyRef:r,headerRef:e})}const Rr={},Br={xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 384 512",width:"1em",height:"1em",fill:"currentColor"},Nr=y("path",{d:"M320 448v40c0 13.255-10.745 24-24 24H24c-13.255 0-24-10.745-24-24V120c0-13.255 10.745-24 24-24h72v296c0 30.879 25.121 56 56 56h168zm0-344V0H152c-13.255 0-24 10.745-24 24v368c0 13.255 10.745 24 24 24h272c13.255 0 24-10.745 24-24V128H344c-13.2 0-24-10.8-24-24zm120.971-31.029L375.029 7.029A24 24 0 0 0 358.059 0H352v96h96v-6.059a24 24 0 0 0-7.029-16.97z"},null,-1),Vr=[Nr];function Fr(a,t){return l(),m("svg",Br,Vr)}const ut=P(Rr,[["render",Fr]]),Hr={},Wr={xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 384 512",width:"1em",height:"1em",fill:"currentColor"},zr=y("path",{d:"M64 0H32V64H64 93.5L82.1 212.1C23.7 240.7 0 293 0 320v32H384V320c0-22.5-23.7-76.5-82.1-106.7L290.5 64H320h32V0H320 64zm96 480v32h64V480 384H160v96z"},null,-1),Yr=[zr];function qr(a,t){return l(),m("svg",Wr,Yr)}const jr=P(Hr,[["render",qr]]),Qr={},Gr={xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512",width:"1em",height:"1em",fill:"currentColor"},Xr=y("path",{d:"M0 208L192 384h32V288h80c61.9 0 112 50.1 112 112c0 48-32 80-32 80s128-48 128-176c0-97.2-78.8-176-176-176H224V32H192L0 208z"},null,-1),Kr=[Xr];function Jr(a,t){return l(),m("svg",Gr,Kr)}const Zr=P(Qr,[["render",Jr]]),es={class:"seventv-copied-message-toast-body"},ts={key:0},as=Y({__name:"UiCopiedMessageToast",props:{message:{}},emits:["close"],setup(a,{emit:t}){const e=S(),r=t;return Zt(e,()=>{r("close")}),(n,s)=>(l(),m("main",{ref_key:"copiedMessageToastRef",ref:e,class:"seventv-copied-message-toast"},[y("div",es,[n.message?(l(),m("p",ts,B(n.message),1)):yt(n.$slots,"default",{key:1},void 0,!0)])],512))}}),ns=P(as,[["__scopeId","data-v-fbb0ba18"]]),rs={class:"seventv-chat-message-buttons"},ss=Y({__name:"UserMessageButtons",props:{msg:{}},emits:["pin"],setup(a,{emit:t}){const e=a,r=t,n=Ar("Reply",()=>{var $,L,R,H,N,b,C;return{id:e.msg.id,body:e.msg.body,deleted:e.msg.moderation.deleted,...e.msg.author?{authorID:($=e.msg.author)==null?void 0:$.id,username:(L=e.msg.author)==null?void 0:L.username,displayName:(R=e.msg.author)==null?void 0:R.displayName}:{},...e.msg.parent?{thread:{deleted:((H=e.msg.parent.thread)==null?void 0:H.deleted)??e.msg.parent.deleted,id:((N=e.msg.parent.thread)==null?void 0:N.id)??e.msg.parent.id,login:((b=e.msg.parent.thread)==null?void 0:b.login)??((C=e.msg.parent.author)==null?void 0:C.username)??""}}:{}}}),s=X("chat.copy_icon_toggle"),i=S(!1),f=S(),g=tt(f,{enabled:()=>i.value,middleware:[Ae({padding:8})]});function u(){i.value||(navigator.clipboard.writeText(`${e.msg.body}	${new Date(e.msg.timestamp).toLocaleTimeString()}`),i.value=!0,Be(()=>{i.value=!1},1e3))}function w(){i.value||(navigator.clipboard.writeText(e.msg.body),i.value=!0,Be(()=>{i.value=!1},1e3))}const _=S(!1),c=S(),v=tt(c,{enabled:()=>_.value,middleware:[Ae({padding:8})]});function h(){n.open()}function o($){$==="yes"&&r("pin")}return($,L)=>{const R=pe("tooltip");return l(),m(q,null,[y("div",rs,[M(s)&&!$.msg.moderation.deleted?Q((l(),m("div",{key:0,ref_key:"copyButtonRef",ref:f,class:"seventv-button",onClick:L[0]||(L[0]=H=>u())},[O(ut)])),[[R,"copy"]]):k("",!0),M(s)&&!$.msg.moderation.deleted?Q((l(),m("div",{key:1,ref_key:"copyButtonRef",ref:f,class:"seventv-button",onClick:L[1]||(L[1]=H=>w())},[O(ut)])),[[R,"Copy"]]):k("",!0),$.msg.pinnable&&!$.msg.moderation.deleted?Q((l(),m("div",{key:2,ref_key:"pinButtonRef",ref:c,class:"seventv-button",onClick:L[2]||(L[2]=H=>_.value=!0)},[O(jr)])),[[R,"Pin"]]):k("",!0),Q((l(),m("div",{class:"seventv-button",onClick:h},[(l(),F(We($.msg.parent?Qe:Zr)))])),[[R,"Reply"]])]),i.value&&M(g)?(l(),F(Re,{key:0,to:M(g)},[O(ns,{title:"Message Copied",onClose:L[3]||(L[3]=H=>i.value=!1)},{default:fe(()=>[Z(" Message from "),$.msg.author?(l(),F(we,{key:0,user:$.msg.author},null,8,["user"])):k("",!0),Z(" has been copied ")]),_:1})],8,["to"])):k("",!0),_.value&&M(v)?(l(),F(Re,{key:1,to:M(v)},[O(ta,{title:"Pin Message?",choices:["yes","no"],onClose:L[4]||(L[4]=H=>_.value=!1),onAnswer:L[5]||(L[5]=H=>o(H))},{default:fe(()=>[Z(" Are you sure you want to pin this message by "),$.msg.author?(l(),F(we,{key:0,user:$.msg.author},null,8,["user"])):k("",!0),Z("? ")]),_:1})],8,["to"])):k("",!0)],64)}}}),os=P(ss,[["__scopeId","data-v-adb60a1b"]]);function G(a,t){if(t.length<a)throw new TypeError(a+" argument"+(a>1?"s":"")+" required, but only "+t.length+" present")}function is(a,t,e){var r;G(1,arguments);var n;return ls(t)?n=t:e=t,new Intl.DateTimeFormat((r=e)===null||r===void 0?void 0:r.locale,n).format(a)}function ls(a){return a!==void 0&&!("locale"in a)}function Ge(a,t){var e=arguments.length>2&&arguments[2]!==void 0?arguments[2]:[];return e.length>=t?a.apply(null,e.slice(0,t).reverse()):function(){for(var r=arguments.length,n=new Array(r),s=0;s<r;s++)n[s]=arguments[s];return Ge(a,t,e.concat(n))}}const us=Ge(is,3),ds=["msg-id","state","data-highlight-style"],cs=["data-highlight-label"],ms={key:1,class:"seventv-chat-message-timestamp"},gs={key:4},hs={class:"seventv-chat-message-body"},vs={key:0,class:"text-token"},fs={key:1},ps={key:0,class:"seventv-chat-message-moderated"},ys={key:1,class:"seventv-chat-message-moderated"},_s=Y({__name:"UserMessage",props:{msg:{},as:{default:"Chat"},highlight:{},emotes:{},chatters:{},isModerator:{type:Boolean},hideAuthor:{type:Boolean},hideModeration:{type:Boolean},hideModIcons:{type:Boolean},hideDeletionState:{type:Boolean},showButtons:{type:Boolean},forceTimestamp:{type:Boolean}},setup(a){var I;const t=a,e=_t(t,"msg"),r=S(),n=ue(),s=Tt(n),{openViewerCard:i}=Ie(n),{pinChatMessage:f}=je(n,((I=e.value.author)==null?void 0:I.username)??""),g=X("chat.emote_scale"),u=X("chat.slash_me_style"),w=X("highlights.display_style"),_=X("highlights.opacity"),c=X("chat.timestamp_with_seconds"),v=X("chat.show_emote_modifiers"),h=X("chat.timestamp_format"),o=navigator.languages&&navigator.languages.length?navigator.languages[0]:navigator.language??"en",$=t.msg.author?Ye(t.msg.author.id):{emotes:{}},L=S(""),R=t.msg.getTokenizer(),H=S([]);function N(){if(!R)return;const x=R.tokenize({chatterMap:t.chatters??{},emoteMap:t.emotes??{},localEmoteMap:{...$.emotes,...t.msg.nativeEmotes},showModifiers:v.value}),V=[],j=t.msg.body;let U=0;for(const T of x){const D=T.range[0],E=T.range[1],W=j.substring(U,D);W&&V.push(W),V.push(T),U=E+1}const d=j.substring(U);d&&V.push(d),H.value=V}function b(){var x;(x=f(e.value.id,1200))==null||x.catch(V=>ie.error("failed to pin chat message",V))}le(()=>[$.emotes,t.msg.nativeEmotes],()=>N(),{immediate:!0}),t.msg.refresh=N,t.msg.historical&&Be(ve(()=>{N()}),1e4);function C(x){if(tn(x))return tr;if(Za(x))return Jn}const p=()=>{switch(h.value){case"infer":return;case"12":return"h12";case"24":return"h23"}};return ve(()=>{!e.value||!r.value||(e.value.highlight&&(r.value.style.setProperty("--seventv-highlight-color",e.value.highlight.color),r.value.style.setProperty("--seventv-highlight-dim-color",e.value.highlight.color.concat(Vt(_.value/100)))),(s.showTimestamps||e.value.historical||t.forceTimestamp)&&(L.value=us({locale:o},{localeMatcher:"lookup",hour:"2-digit",minute:"2-digit",second:c.value?"numeric":void 0,hourCycle:p()},t.msg.timestamp)))}),(x,V)=>{var j;return l(),m("span",{ref_key:"msgEl",ref:r,class:ft(["seventv-user-message",{deleted:!x.hideDeletionState&&(e.value.moderation.banned||e.value.moderation.deleted),"has-mention":x.as=="Chat"&&e.value.mentions.has("#actor"),"has-highlight":x.as=="Chat"&&e.value.highlight}]),"msg-id":e.value.id,state:e.value.deliveryState,style:$e({"font-style":e.value.slashMe&&M(u)&1?"italic":"",color:e.value.slashMe&&M(u)&2?(j=e.value.author)==null?void 0:j.color:""}),"data-highlight-style":M(w)},[e.value.highlight?(l(),m("div",{key:0,class:"seventv-chat-message-highlight-label","data-highlight-label":e.value.highlight.label},null,8,cs)):k("",!0),M(s).showTimestamps||e.value.historical||x.forceTimestamp?(l(),m("span",ms,B(L.value),1)):k("",!0),M(n).actor.roles.has("MODERATOR")&&M(s).showModerationIcons&&!x.hideModIcons?(l(),F(xn,{key:2,msg:e.value},null,8,["msg"])):k("",!0),e.value.author&&!x.hideAuthor?(l(),F(we,{key:3,user:e.value.author,"source-data":e.value.sourceData,badges:e.value.badges,"msg-id":e.value.sym,onOpenNativeCard:V[0]||(V[0]=U=>M(i)(U,e.value.author.username,e.value.id))},null,8,["user","source-data","badges","msg-id"])):k("",!0),x.hideAuthor?k("",!0):(l(),m("span",gs,B(e.value.slashMe?" ":": "),1)),y("span",hs,[(l(!0),m(q,null,re(H.value,(U,d)=>(l(),m(q,{key:d},[typeof U=="string"?(l(),m("span",vs,B(U),1)):M(en)(U)?(l(),m("span",fs,[O(Mt,{class:"emote-token",emote:U.content.emote,format:M(s).imageFormat,overlaid:U.content.overlaid,clickable:!0,scale:Number(M(g))},null,8,["emote","format","overlaid","scale"]),U.content?(l(),m("span",{key:0,style:$e({color:U.content.cheerColor})},B(U.content.cheerAmount),5)):k("",!0)])):(l(),F(We(C(U)),Pt(bt({key:2},{token:U,msg:e.value})),null,16))],64))),128))]),e.value.richEmbed.request_url?(l(),F(mr,{key:5,"rich-embed":e.value.richEmbed},null,8,["rich-embed"])):k("",!0),e.value.emoteLinkEmbed?(l(),F(Xn,{key:6,"emote-id":e.value.emoteLinkEmbed},null,8,["emote-id"])):k("",!0),!x.hideModeration&&(e.value.moderation.banned||e.value.moderation.deleted)?(l(),m(q,{key:7},[e.value.moderation.banned?(l(),m("span",ps,B(e.value.moderation.banDuration?`Timed out (${e.value.moderation.banDuration}s)`:"Permanently Banned"),1)):(l(),m("span",ys,"Deleted"))],64)):k("",!0),O(os,{msg:e.value,onPin:V[1]||(V[1]=U=>b())},null,8,["msg"])],14,ds)}}}),Fe=P(_s,[["__scopeId","data-v-c228556a"]]),bs={class:"seventv-chat-message-container"},ws={class:"seventv-chat-message-background",tabindex:"0"},Cs={key:0,class:"seventv-reply-part"},Ms={class:"seventv-chat-reply-icon"},$s={class:"seventv-reply-message-part"},Ts=Y({__name:"0.NormalMessage",props:{msg:{},msgData:{}},setup(a){return(t,e)=>{const r=pe("tooltip");return l(),m("div",bs,[y("div",ws,[t.msgData.reply?(l(),m("div",Cs,[y("div",Ms,[O(Qe)]),Q((l(),m("div",$s,[Z(B(`Replying to @${t.msgData.reply.parentDisplayName}: ${t.msgData.reply.parentMessageBody}`),1)])),[[r,`Replying to @${t.msgData.reply.parentDisplayName}: ${t.msgData.reply.parentMessageBody}`]])])):k("",!0),yt(t.$slots,"default",{},void 0,!0)])])}}}),ks=P(Ts,[["__scopeId","data-v-7a7ddc21"]]),kt=a=>(At("data-v-21ba2f53"),a=a(),Rt(),a),Us={key:0,class:"seventv-user-card-message-timeline"},Ds=["timeline-id"],Ls=kt(()=>y("div",{selector:"date-boundary"},null,-1)),Is=kt(()=>y("div",{selector:"date-boundary"},null,-1)),Ss={class:"seventv-user-card-message-timeline-list"},Es={key:1,class:"seventv-user-card-message-timeline-empty"},Ps={key:2,class:"seventv-user-card-mod-comment-input-container"},Os=["placeholder","onKeydown"],xs=Y({__name:"UserCardMessageList",props:{activeTab:{},target:{},timeline:{},scroller:{}},emits:["add-mod-comment"],setup(a,{emit:t}){const e=a,r=t,{t:n}=ze(),s=ue(),i=He(s),f=zt(!0,10),g=Le(),u=S("");function w(){var c;(c=e.scroller)!=null&&c.container&&e.scroller.container.scrollTo({top:e.scroller.container.scrollHeight})}async function _(){var h;if(!u.value||!g.value)return;const c=u.value;u.value="";const v=await g.value.mutate({mutation:$a,variables:{input:{channelID:s.id,targetID:e.target.id,text:c}}}).catch(o=>ie.error("failed to add mod comment",o));!v||!v.data||!v.data.createModeratorComment||(r("add-mod-comment",(h=v.data)==null?void 0:h.createModeratorComment.comment),De(w))}return le(()=>e.activeTab,()=>{f.value=!1,setTimeout(()=>{w()},10)}),le(e.timeline,()=>{var c;!((c=e.scroller)!=null&&c.container)||e.scroller.container.scrollTop!==0||w()}),(c,v)=>M(f)?(l(),m("div",Us,[Object.keys(e.timeline).length?(l(!0),m(q,{key:0},re(Object.entries(e.timeline).reverse(),([h,o])=>(l(),m("section",{key:h,"timeline-id":h},[Ls,y("label",null,B(h),1),Is,y("div",Ss,[(l(!0),m(q,null,re(o,$=>(l(),m(q,{key:$.sym},[$.instance&&$.instance!==ks?(l(),F(We($.instance),bt({key:0},$.componentProps,{msg:$}),{default:fe(()=>[O(Fe,{msg:$,emotes:M(i).active,"hide-mod-icons":!0,"force-timestamp":!0},null,8,["msg","emotes"])]),_:2},1040,["msg"])):(l(),F(Fe,{key:1,msg:$,emotes:M(i).active,"hide-mod-icons":!0,"force-timestamp":!0},null,8,["msg","emotes"]))],64))),128))])],8,Ds))),128)):(l(),m("div",Es,[y("p",null,B(M(n)(`user_card.no_${c.activeTab}`,{user:c.target.displayName})),1)])),c.activeTab==="comments"?(l(),m("div",Ps,[Q(y("input",{id:"seventv-user-card-mod-comment-input","onUpdate:modelValue":v[0]||(v[0]=h=>u.value=h),placeholder:M(n)("user_card.add_comment_input_placeholder"),onKeydown:xt(_,["enter"])},null,40,Os),[[Ot,u.value]])])):k("",!0)])):k("",!0)}}),As=P(xs,[["__scopeId","data-v-21ba2f53"]]),Rs={mlns:"http://www.w3.org/2000/svg",viewBox:"0 0 640 512",width:"1em",height:"1em",fill:"currentColor"},Bs={key:0,d:"M408 56L384 80c37.3 37.3 74.7 74.7 112 112c8-8 16-16 24-24l56 56c-37.5 37.5-74.9 74.9-112.4 112.4c59.1 45.9 118.2 91.7 177.3 137.6c-9.8 12.6-19.6 25.3-29.4 37.9C407.9 353.9 204.5 195.9 1 38C10.8 25.3 20.6 12.7 30.4 .1c60.3 46.8 120.7 93.7 181 140.5C258.3 93.7 305.1 46.9 352 0c18.7 18.7 37.3 37.3 56 56zM288 176l-13.5 13.5c40.3 31.3 80.7 62.7 121 94C359.7 247.7 323.8 211.8 288 176zm-9.4 166.7c5.8 5.7 11.6 11.5 17.4 17.3c-50.7 50.7-101.3 101.3-152 152c-26.7-26.7-53.3-53.3-80-80c50.7-50.7 101.3-101.3 152-152c5.8 5.8 11.6 11.6 17.4 17.4c3.3-3.3 6.5-6.5 9.8-9.8c16.9 13.3 33.8 26.6 50.6 39.9c-5.1 5.1-10.1 10.1-15.2 15.2z"},Ns={key:1,d:"M344 56L320 80 432 192l24-24 56 56L368 368l-56-56 24-24L224 176l-24 24-56-56L288 0l56 56zM214.6 342.6L232 360 80 512 0 432 152 280l17.4 17.4L234.7 232 280 277.3l-65.4 65.4z"},Vs=Y({__name:"GavelIcon",props:{slashed:{type:Boolean}},setup(a){return(t,e)=>(l(),m("svg",Rs,[t.slashed?(l(),m("path",Bs)):(l(),m("path",Ns))]))}}),Fs={xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 640 512",width:"1em",height:"1em",fill:"currentColor"},Hs={key:0,d:"M496.8 363l124.1 96.3 19 14.7-29.4 37.9-19-14.7L19 52.7 0 38 29.4 .1l19 14.7 77.8 60.4L308.4 4.5 320 0l11.6 4.5L539.1 85l19.2 7.4 1.2 20.5c2.9 50-4.9 126.3-37.3 200.9c-7.2 16.5-15.6 32.9-25.3 49zM170.4 109.5L458.6 333.3c7.4-12.6 13.9-25.5 19.5-38.5C505 232.9 512.9 169.5 512 126L320 51.5l-149.6 58zm-8.5 185.2c28.2 64.9 77 127.7 158.1 164.8c30-13.7 55.6-31 77.3-50.5l38.2 30.1c-28.1 26.5-62 49.7-102.8 67.3L320 512l-12.7-5.5c-98.4-42.6-156.7-117.3-189.4-192.6c-23.5-54.1-34.1-109-37-154.2l53.3 42c5.2 29.5 13.9 61.5 27.7 93z"},Ws={key:1,d:"M267.6 4.5L256 0 244.4 4.5 36.9 85 17.8 92.5 16.6 113c-2.9 49.9 4.9 126.3 37.3 200.9c32.7 75.3 91 150 189.4 192.6L256 512l12.7-5.5c98.4-42.6 156.7-117.3 189.4-192.6c32.4-74.7 40.2-151 37.3-200.9l-1.2-20.5L475.1 85 267.6 4.5zM256 68.7l0 0L432 137c-.5 40.9-8.8 96.8-32.6 151.5c-26.2 60.3-70.6 118-143.5 153.5V68.7z"},zs=Y({__name:"ShieldIcon",props:{slashed:{type:Boolean}},setup(a){return(t,e)=>(l(),m("svg",Fs,[t.slashed?(l(),m("path",Hs)):(l(),m("path",Ws))]))}}),Ys={},qs={xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 448 512",fill:"currentColor",width:"1em",height:"1em"},js=y("path",{d:"M448 32H0V480H448V32zM248 128v24V264v24H200V264 152 128h48zM200 320h48v48H200V320z"},null,-1),Qs=[js];function Gs(a,t){return l(),m("svg",qs,Qs)}const Xs=P(Ys,[["render",Gs]]),Ks={class:"seventv-user-card-mod"},Js=["is-banned"],Zs={class:"seventv-user-card-mod-side seventv-user-card-mod-warn"},eo={class:"seventv-user-card-mod-timeout-options"},to=["onClick"],ao=["is-mod"],no=Y({__name:"UserCardMod",props:{target:{},ban:{},isModerator:{type:Boolean}},emits:["victim-banned","victim-unbanned","victim-modded","victim-unmodded"],setup(a,{emit:t}){const e=a,r=t,{t:n}=ze(),s=ue(),i=je(s,e.target.username),f=Ie(s);async function g(c){var h,o,$;const v=await i.banUserFromChat(c).catch(()=>{});!v||(h=v.errors)!=null&&h.length||!((o=v.data)!=null&&o.banUserFromChatRoom.ban)||r("victim-banned",($=v.data)==null?void 0:$.banUserFromChatRoom.ban)}async function u(){var v;const c=await i.unbanUserFromChat().catch(()=>{});!c||(v=c.errors)!=null&&v.length||r("victim-unbanned")}async function w(c){var h;const v=await i.setUserModerator(e.target.id,c).catch(()=>{});!v||(h=v.errors)!=null&&h.length||r(c?"victim-unmodded":"victim-modded")}const _=["1s","30s","1m","10m","30m","1h","4h","12h","1d","7d","14d"];return(c,v)=>{const h=pe("tooltip");return l(),m("div",Ks,[y("div",{class:"seventv-user-card-mod-side seventv-user-card-mod-ban","is-banned":c.ban?"1":"0"},[Q(O(Vs,{slashed:!!c.ban,onClick:v[0]||(v[0]=o=>c.ban?u():g(""))},null,8,["slashed"]),[[h,c.ban?M(n)("user_card.unban_button"):M(n)("user_card.ban_button")]])],8,Js),y("div",Zs,[Q(O(Xs,{onClick:v[1]||(v[1]=o=>M(f).openViewerWarnPopover(c.target.id,c.target.username,0))},null,512),[[h,M(n)("user_card.warn_button")]])]),Q(y("div",eo,[(l(),m(q,null,re(_,o=>Q(y("button",{key:o,onClick:$=>g(o)},[Z(B(o),1)],8,to),[[h,M(n)("user_card.timeout_button",{duration:o})]])),64))],512),[[Bt,!c.ban]]),M(s).actor.roles.has("BROADCASTER")?(l(),m("div",{key:0,class:"seventv-user-card-mod-side seventv-user-card-mod-moderator","is-mod":c.isModerator?"1":"0"},[Q(O(zs,{slashed:c.isModerator,onClick:v[2]||(v[2]=o=>w(!!c.isModerator))},null,8,["slashed"]),[[h,c.isModerator?M(n)("user_card.unmod_button"):M(n)("user_card.mod_button")]])],8,ao)):k("",!0)])}}}),ro=P(no,[["__scopeId","data-v-bb759d6b"]]),so={class:"seventv-user-card-tabs"},oo=["selected","onClick"],io=Y({__name:"UserCardTabs",props:{activeTab:{},messageCount:{},warningCount:{},timeoutCount:{},banCount:{},commentCount:{}},emits:["switch"],setup(a,{emit:t}){const e=a,r=t,n=te(()=>[{id:"messages",label:"Messages",count:e.messageCount,maxCount:1e3},{id:"warnings",label:"Warnings",count:e.warningCount,maxCount:99},{id:"timeouts",label:"Timeouts",count:e.timeoutCount,maxCount:99},{id:"bans",label:"Bans",count:e.banCount,maxCount:99},{id:"comments",label:"Comments",count:e.commentCount,maxCount:10}]);function s(i,f){return i>=f?f.toString()+"+":i.toString()}return(i,f)=>(l(),m("div",so,[(l(!0),m(q,null,re(n.value,g=>(l(),m("button",{key:g.label,selected:i.activeTab===g.id,onClick:u=>r("switch",g.id)},[Z(B(s(g.count,g.maxCount))+" ",1),y("p",null,B(g.label),1)],8,oo))),128))]))}}),lo=P(io,[["__scopeId","data-v-52560988"]]),uo={class:"seventv-basic-system-message"},co=Y({__name:"BasicSystemMessage",props:{text:{}},setup(a){return(t,e)=>(l(),m("span",uo,B(t.text),1))}}),mo=P(co,[["__scopeId","data-v-0218c5a7"]]);function Te(a){"@babel/helpers - typeof";return Te=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(t){return typeof t}:function(t){return t&&typeof Symbol=="function"&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t},Te(a)}function go(a){return G(1,arguments),a instanceof Date||Te(a)==="object"&&Object.prototype.toString.call(a)==="[object Date]"}function ae(a){G(1,arguments);var t=Object.prototype.toString.call(a);return a instanceof Date||Te(a)==="object"&&t==="[object Date]"?new Date(a.getTime()):typeof a=="number"||t==="[object Number]"?new Date(a):((typeof a=="string"||t==="[object String]")&&typeof console<"u"&&(console.warn("Starting with v2.0.0-beta.1 date-fns doesn't accept strings as date arguments. Please use `parseISO` to parse strings. See: https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#string-arguments"),console.warn(new Error().stack)),new Date(NaN))}function ho(a){if(G(1,arguments),!go(a)&&typeof a!="number")return!1;var t=ae(a);return!isNaN(Number(t))}function me(a){if(a===null||a===!0||a===!1)return NaN;var t=Number(a);return isNaN(t)?t:t<0?Math.ceil(t):Math.floor(t)}function vo(a,t){G(2,arguments);var e=ae(a).getTime(),r=me(t);return new Date(e+r)}function fo(a,t){G(2,arguments);var e=me(t);return vo(a,-e)}var po=864e5;function yo(a){G(1,arguments);var t=ae(a),e=t.getTime();t.setUTCMonth(0,1),t.setUTCHours(0,0,0,0);var r=t.getTime(),n=e-r;return Math.floor(n/po)+1}function ke(a){G(1,arguments);var t=1,e=ae(a),r=e.getUTCDay(),n=(r<t?7:0)+r-t;return e.setUTCDate(e.getUTCDate()-n),e.setUTCHours(0,0,0,0),e}function Ut(a){G(1,arguments);var t=ae(a),e=t.getUTCFullYear(),r=new Date(0);r.setUTCFullYear(e+1,0,4),r.setUTCHours(0,0,0,0);var n=ke(r),s=new Date(0);s.setUTCFullYear(e,0,4),s.setUTCHours(0,0,0,0);var i=ke(s);return t.getTime()>=n.getTime()?e+1:t.getTime()>=i.getTime()?e:e-1}function _o(a){G(1,arguments);var t=Ut(a),e=new Date(0);e.setUTCFullYear(t,0,4),e.setUTCHours(0,0,0,0);var r=ke(e);return r}var bo=6048e5;function wo(a){G(1,arguments);var t=ae(a),e=ke(t).getTime()-_o(t).getTime();return Math.round(e/bo)+1}var Co={};function Se(){return Co}function Ue(a,t){var e,r,n,s,i,f,g,u;G(1,arguments);var w=Se(),_=me((e=(r=(n=(s=t==null?void 0:t.weekStartsOn)!==null&&s!==void 0?s:t==null||(i=t.locale)===null||i===void 0||(f=i.options)===null||f===void 0?void 0:f.weekStartsOn)!==null&&n!==void 0?n:w.weekStartsOn)!==null&&r!==void 0?r:(g=w.locale)===null||g===void 0||(u=g.options)===null||u===void 0?void 0:u.weekStartsOn)!==null&&e!==void 0?e:0);if(!(_>=0&&_<=6))throw new RangeError("weekStartsOn must be between 0 and 6 inclusively");var c=ae(a),v=c.getUTCDay(),h=(v<_?7:0)+v-_;return c.setUTCDate(c.getUTCDate()-h),c.setUTCHours(0,0,0,0),c}function Dt(a,t){var e,r,n,s,i,f,g,u;G(1,arguments);var w=ae(a),_=w.getUTCFullYear(),c=Se(),v=me((e=(r=(n=(s=t==null?void 0:t.firstWeekContainsDate)!==null&&s!==void 0?s:t==null||(i=t.locale)===null||i===void 0||(f=i.options)===null||f===void 0?void 0:f.firstWeekContainsDate)!==null&&n!==void 0?n:c.firstWeekContainsDate)!==null&&r!==void 0?r:(g=c.locale)===null||g===void 0||(u=g.options)===null||u===void 0?void 0:u.firstWeekContainsDate)!==null&&e!==void 0?e:1);if(!(v>=1&&v<=7))throw new RangeError("firstWeekContainsDate must be between 1 and 7 inclusively");var h=new Date(0);h.setUTCFullYear(_+1,0,v),h.setUTCHours(0,0,0,0);var o=Ue(h,t),$=new Date(0);$.setUTCFullYear(_,0,v),$.setUTCHours(0,0,0,0);var L=Ue($,t);return w.getTime()>=o.getTime()?_+1:w.getTime()>=L.getTime()?_:_-1}function Mo(a,t){var e,r,n,s,i,f,g,u;G(1,arguments);var w=Se(),_=me((e=(r=(n=(s=t==null?void 0:t.firstWeekContainsDate)!==null&&s!==void 0?s:t==null||(i=t.locale)===null||i===void 0||(f=i.options)===null||f===void 0?void 0:f.firstWeekContainsDate)!==null&&n!==void 0?n:w.firstWeekContainsDate)!==null&&r!==void 0?r:(g=w.locale)===null||g===void 0||(u=g.options)===null||u===void 0?void 0:u.firstWeekContainsDate)!==null&&e!==void 0?e:1),c=Dt(a,t),v=new Date(0);v.setUTCFullYear(c,0,_),v.setUTCHours(0,0,0,0);var h=Ue(v,t);return h}var $o=6048e5;function To(a,t){G(1,arguments);var e=ae(a),r=Ue(e,t).getTime()-Mo(e,t).getTime();return Math.round(r/$o)+1}function A(a,t){for(var e=a<0?"-":"",r=Math.abs(a).toString();r.length<t;)r="0"+r;return e+r}var ko={y:function(t,e){var r=t.getUTCFullYear(),n=r>0?r:1-r;return A(e==="yy"?n%100:n,e.length)},M:function(t,e){var r=t.getUTCMonth();return e==="M"?String(r+1):A(r+1,2)},d:function(t,e){return A(t.getUTCDate(),e.length)},a:function(t,e){var r=t.getUTCHours()/12>=1?"pm":"am";switch(e){case"a":case"aa":return r.toUpperCase();case"aaa":return r;case"aaaaa":return r[0];case"aaaa":default:return r==="am"?"a.m.":"p.m."}},h:function(t,e){return A(t.getUTCHours()%12||12,e.length)},H:function(t,e){return A(t.getUTCHours(),e.length)},m:function(t,e){return A(t.getUTCMinutes(),e.length)},s:function(t,e){return A(t.getUTCSeconds(),e.length)},S:function(t,e){var r=e.length,n=t.getUTCMilliseconds(),s=Math.floor(n*Math.pow(10,r-3));return A(s,e.length)}};const oe=ko;var he={am:"am",pm:"pm",midnight:"midnight",noon:"noon",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"},Uo={G:function(t,e,r){var n=t.getUTCFullYear()>0?1:0;switch(e){case"G":case"GG":case"GGG":return r.era(n,{width:"abbreviated"});case"GGGGG":return r.era(n,{width:"narrow"});case"GGGG":default:return r.era(n,{width:"wide"})}},y:function(t,e,r){if(e==="yo"){var n=t.getUTCFullYear(),s=n>0?n:1-n;return r.ordinalNumber(s,{unit:"year"})}return oe.y(t,e)},Y:function(t,e,r,n){var s=Dt(t,n),i=s>0?s:1-s;if(e==="YY"){var f=i%100;return A(f,2)}return e==="Yo"?r.ordinalNumber(i,{unit:"year"}):A(i,e.length)},R:function(t,e){var r=Ut(t);return A(r,e.length)},u:function(t,e){var r=t.getUTCFullYear();return A(r,e.length)},Q:function(t,e,r){var n=Math.ceil((t.getUTCMonth()+1)/3);switch(e){case"Q":return String(n);case"QQ":return A(n,2);case"Qo":return r.ordinalNumber(n,{unit:"quarter"});case"QQQ":return r.quarter(n,{width:"abbreviated",context:"formatting"});case"QQQQQ":return r.quarter(n,{width:"narrow",context:"formatting"});case"QQQQ":default:return r.quarter(n,{width:"wide",context:"formatting"})}},q:function(t,e,r){var n=Math.ceil((t.getUTCMonth()+1)/3);switch(e){case"q":return String(n);case"qq":return A(n,2);case"qo":return r.ordinalNumber(n,{unit:"quarter"});case"qqq":return r.quarter(n,{width:"abbreviated",context:"standalone"});case"qqqqq":return r.quarter(n,{width:"narrow",context:"standalone"});case"qqqq":default:return r.quarter(n,{width:"wide",context:"standalone"})}},M:function(t,e,r){var n=t.getUTCMonth();switch(e){case"M":case"MM":return oe.M(t,e);case"Mo":return r.ordinalNumber(n+1,{unit:"month"});case"MMM":return r.month(n,{width:"abbreviated",context:"formatting"});case"MMMMM":return r.month(n,{width:"narrow",context:"formatting"});case"MMMM":default:return r.month(n,{width:"wide",context:"formatting"})}},L:function(t,e,r){var n=t.getUTCMonth();switch(e){case"L":return String(n+1);case"LL":return A(n+1,2);case"Lo":return r.ordinalNumber(n+1,{unit:"month"});case"LLL":return r.month(n,{width:"abbreviated",context:"standalone"});case"LLLLL":return r.month(n,{width:"narrow",context:"standalone"});case"LLLL":default:return r.month(n,{width:"wide",context:"standalone"})}},w:function(t,e,r,n){var s=To(t,n);return e==="wo"?r.ordinalNumber(s,{unit:"week"}):A(s,e.length)},I:function(t,e,r){var n=wo(t);return e==="Io"?r.ordinalNumber(n,{unit:"week"}):A(n,e.length)},d:function(t,e,r){return e==="do"?r.ordinalNumber(t.getUTCDate(),{unit:"date"}):oe.d(t,e)},D:function(t,e,r){var n=yo(t);return e==="Do"?r.ordinalNumber(n,{unit:"dayOfYear"}):A(n,e.length)},E:function(t,e,r){var n=t.getUTCDay();switch(e){case"E":case"EE":case"EEE":return r.day(n,{width:"abbreviated",context:"formatting"});case"EEEEE":return r.day(n,{width:"narrow",context:"formatting"});case"EEEEEE":return r.day(n,{width:"short",context:"formatting"});case"EEEE":default:return r.day(n,{width:"wide",context:"formatting"})}},e:function(t,e,r,n){var s=t.getUTCDay(),i=(s-n.weekStartsOn+8)%7||7;switch(e){case"e":return String(i);case"ee":return A(i,2);case"eo":return r.ordinalNumber(i,{unit:"day"});case"eee":return r.day(s,{width:"abbreviated",context:"formatting"});case"eeeee":return r.day(s,{width:"narrow",context:"formatting"});case"eeeeee":return r.day(s,{width:"short",context:"formatting"});case"eeee":default:return r.day(s,{width:"wide",context:"formatting"})}},c:function(t,e,r,n){var s=t.getUTCDay(),i=(s-n.weekStartsOn+8)%7||7;switch(e){case"c":return String(i);case"cc":return A(i,e.length);case"co":return r.ordinalNumber(i,{unit:"day"});case"ccc":return r.day(s,{width:"abbreviated",context:"standalone"});case"ccccc":return r.day(s,{width:"narrow",context:"standalone"});case"cccccc":return r.day(s,{width:"short",context:"standalone"});case"cccc":default:return r.day(s,{width:"wide",context:"standalone"})}},i:function(t,e,r){var n=t.getUTCDay(),s=n===0?7:n;switch(e){case"i":return String(s);case"ii":return A(s,e.length);case"io":return r.ordinalNumber(s,{unit:"day"});case"iii":return r.day(n,{width:"abbreviated",context:"formatting"});case"iiiii":return r.day(n,{width:"narrow",context:"formatting"});case"iiiiii":return r.day(n,{width:"short",context:"formatting"});case"iiii":default:return r.day(n,{width:"wide",context:"formatting"})}},a:function(t,e,r){var n=t.getUTCHours(),s=n/12>=1?"pm":"am";switch(e){case"a":case"aa":return r.dayPeriod(s,{width:"abbreviated",context:"formatting"});case"aaa":return r.dayPeriod(s,{width:"abbreviated",context:"formatting"}).toLowerCase();case"aaaaa":return r.dayPeriod(s,{width:"narrow",context:"formatting"});case"aaaa":default:return r.dayPeriod(s,{width:"wide",context:"formatting"})}},b:function(t,e,r){var n=t.getUTCHours(),s;switch(n===12?s=he.noon:n===0?s=he.midnight:s=n/12>=1?"pm":"am",e){case"b":case"bb":return r.dayPeriod(s,{width:"abbreviated",context:"formatting"});case"bbb":return r.dayPeriod(s,{width:"abbreviated",context:"formatting"}).toLowerCase();case"bbbbb":return r.dayPeriod(s,{width:"narrow",context:"formatting"});case"bbbb":default:return r.dayPeriod(s,{width:"wide",context:"formatting"})}},B:function(t,e,r){var n=t.getUTCHours(),s;switch(n>=17?s=he.evening:n>=12?s=he.afternoon:n>=4?s=he.morning:s=he.night,e){case"B":case"BB":case"BBB":return r.dayPeriod(s,{width:"abbreviated",context:"formatting"});case"BBBBB":return r.dayPeriod(s,{width:"narrow",context:"formatting"});case"BBBB":default:return r.dayPeriod(s,{width:"wide",context:"formatting"})}},h:function(t,e,r){if(e==="ho"){var n=t.getUTCHours()%12;return n===0&&(n=12),r.ordinalNumber(n,{unit:"hour"})}return oe.h(t,e)},H:function(t,e,r){return e==="Ho"?r.ordinalNumber(t.getUTCHours(),{unit:"hour"}):oe.H(t,e)},K:function(t,e,r){var n=t.getUTCHours()%12;return e==="Ko"?r.ordinalNumber(n,{unit:"hour"}):A(n,e.length)},k:function(t,e,r){var n=t.getUTCHours();return n===0&&(n=24),e==="ko"?r.ordinalNumber(n,{unit:"hour"}):A(n,e.length)},m:function(t,e,r){return e==="mo"?r.ordinalNumber(t.getUTCMinutes(),{unit:"minute"}):oe.m(t,e)},s:function(t,e,r){return e==="so"?r.ordinalNumber(t.getUTCSeconds(),{unit:"second"}):oe.s(t,e)},S:function(t,e){return oe.S(t,e)},X:function(t,e,r,n){var s=n._originalDate||t,i=s.getTimezoneOffset();if(i===0)return"Z";switch(e){case"X":return ct(i);case"XXXX":case"XX":return de(i);case"XXXXX":case"XXX":default:return de(i,":")}},x:function(t,e,r,n){var s=n._originalDate||t,i=s.getTimezoneOffset();switch(e){case"x":return ct(i);case"xxxx":case"xx":return de(i);case"xxxxx":case"xxx":default:return de(i,":")}},O:function(t,e,r,n){var s=n._originalDate||t,i=s.getTimezoneOffset();switch(e){case"O":case"OO":case"OOO":return"GMT"+dt(i,":");case"OOOO":default:return"GMT"+de(i,":")}},z:function(t,e,r,n){var s=n._originalDate||t,i=s.getTimezoneOffset();switch(e){case"z":case"zz":case"zzz":return"GMT"+dt(i,":");case"zzzz":default:return"GMT"+de(i,":")}},t:function(t,e,r,n){var s=n._originalDate||t,i=Math.floor(s.getTime()/1e3);return A(i,e.length)},T:function(t,e,r,n){var s=n._originalDate||t,i=s.getTime();return A(i,e.length)}};function dt(a,t){var e=a>0?"-":"+",r=Math.abs(a),n=Math.floor(r/60),s=r%60;if(s===0)return e+String(n);var i=t||"";return e+String(n)+i+A(s,2)}function ct(a,t){if(a%60===0){var e=a>0?"-":"+";return e+A(Math.abs(a)/60,2)}return de(a,t)}function de(a,t){var e=t||"",r=a>0?"-":"+",n=Math.abs(a),s=A(Math.floor(n/60),2),i=A(n%60,2);return r+s+e+i}const Do=Uo;var mt=function(t,e){switch(t){case"P":return e.date({width:"short"});case"PP":return e.date({width:"medium"});case"PPP":return e.date({width:"long"});case"PPPP":default:return e.date({width:"full"})}},Lt=function(t,e){switch(t){case"p":return e.time({width:"short"});case"pp":return e.time({width:"medium"});case"ppp":return e.time({width:"long"});case"pppp":default:return e.time({width:"full"})}},Lo=function(t,e){var r=t.match(/(P+)(p+)?/)||[],n=r[1],s=r[2];if(!s)return mt(t,e);var i;switch(n){case"P":i=e.dateTime({width:"short"});break;case"PP":i=e.dateTime({width:"medium"});break;case"PPP":i=e.dateTime({width:"long"});break;case"PPPP":default:i=e.dateTime({width:"full"});break}return i.replace("{{date}}",mt(n,e)).replace("{{time}}",Lt(s,e))},Io={p:Lt,P:Lo};const So=Io;function Eo(a){var t=new Date(Date.UTC(a.getFullYear(),a.getMonth(),a.getDate(),a.getHours(),a.getMinutes(),a.getSeconds(),a.getMilliseconds()));return t.setUTCFullYear(a.getFullYear()),a.getTime()-t.getTime()}var Po=["D","DD"],Oo=["YY","YYYY"];function xo(a){return Po.indexOf(a)!==-1}function Ao(a){return Oo.indexOf(a)!==-1}function gt(a,t,e){if(a==="YYYY")throw new RangeError("Use `yyyy` instead of `YYYY` (in `".concat(t,"`) for formatting years to the input `").concat(e,"`; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md"));if(a==="YY")throw new RangeError("Use `yy` instead of `YY` (in `".concat(t,"`) for formatting years to the input `").concat(e,"`; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md"));if(a==="D")throw new RangeError("Use `d` instead of `D` (in `".concat(t,"`) for formatting days of the month to the input `").concat(e,"`; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md"));if(a==="DD")throw new RangeError("Use `dd` instead of `DD` (in `".concat(t,"`) for formatting days of the month to the input `").concat(e,"`; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md"))}var Ro={lessThanXSeconds:{one:"less than a second",other:"less than {{count}} seconds"},xSeconds:{one:"1 second",other:"{{count}} seconds"},halfAMinute:"half a minute",lessThanXMinutes:{one:"less than a minute",other:"less than {{count}} minutes"},xMinutes:{one:"1 minute",other:"{{count}} minutes"},aboutXHours:{one:"about 1 hour",other:"about {{count}} hours"},xHours:{one:"1 hour",other:"{{count}} hours"},xDays:{one:"1 day",other:"{{count}} days"},aboutXWeeks:{one:"about 1 week",other:"about {{count}} weeks"},xWeeks:{one:"1 week",other:"{{count}} weeks"},aboutXMonths:{one:"about 1 month",other:"about {{count}} months"},xMonths:{one:"1 month",other:"{{count}} months"},aboutXYears:{one:"about 1 year",other:"about {{count}} years"},xYears:{one:"1 year",other:"{{count}} years"},overXYears:{one:"over 1 year",other:"over {{count}} years"},almostXYears:{one:"almost 1 year",other:"almost {{count}} years"}},Bo=function(t,e,r){var n,s=Ro[t];return typeof s=="string"?n=s:e===1?n=s.one:n=s.other.replace("{{count}}",e.toString()),r!=null&&r.addSuffix?r.comparison&&r.comparison>0?"in "+n:n+" ago":n};const No=Bo;function xe(a){return function(){var t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},e=t.width?String(t.width):a.defaultWidth,r=a.formats[e]||a.formats[a.defaultWidth];return r}}var Vo={full:"EEEE, MMMM do, y",long:"MMMM do, y",medium:"MMM d, y",short:"MM/dd/yyyy"},Fo={full:"h:mm:ss a zzzz",long:"h:mm:ss a z",medium:"h:mm:ss a",short:"h:mm a"},Ho={full:"{{date}} 'at' {{time}}",long:"{{date}} 'at' {{time}}",medium:"{{date}}, {{time}}",short:"{{date}}, {{time}}"},Wo={date:xe({formats:Vo,defaultWidth:"full"}),time:xe({formats:Fo,defaultWidth:"full"}),dateTime:xe({formats:Ho,defaultWidth:"full"})};const zo=Wo;var Yo={lastWeek:"'last' eeee 'at' p",yesterday:"'yesterday at' p",today:"'today at' p",tomorrow:"'tomorrow at' p",nextWeek:"eeee 'at' p",other:"P"},qo=function(t,e,r,n){return Yo[t]};const jo=qo;function ye(a){return function(t,e){var r=e!=null&&e.context?String(e.context):"standalone",n;if(r==="formatting"&&a.formattingValues){var s=a.defaultFormattingWidth||a.defaultWidth,i=e!=null&&e.width?String(e.width):s;n=a.formattingValues[i]||a.formattingValues[s]}else{var f=a.defaultWidth,g=e!=null&&e.width?String(e.width):a.defaultWidth;n=a.values[g]||a.values[f]}var u=a.argumentCallback?a.argumentCallback(t):t;return n[u]}}var Qo={narrow:["B","A"],abbreviated:["BC","AD"],wide:["Before Christ","Anno Domini"]},Go={narrow:["1","2","3","4"],abbreviated:["Q1","Q2","Q3","Q4"],wide:["1st quarter","2nd quarter","3rd quarter","4th quarter"]},Xo={narrow:["J","F","M","A","M","J","J","A","S","O","N","D"],abbreviated:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],wide:["January","February","March","April","May","June","July","August","September","October","November","December"]},Ko={narrow:["S","M","T","W","T","F","S"],short:["Su","Mo","Tu","We","Th","Fr","Sa"],abbreviated:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],wide:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]},Jo={narrow:{am:"a",pm:"p",midnight:"mi",noon:"n",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"},abbreviated:{am:"AM",pm:"PM",midnight:"midnight",noon:"noon",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"},wide:{am:"a.m.",pm:"p.m.",midnight:"midnight",noon:"noon",morning:"morning",afternoon:"afternoon",evening:"evening",night:"night"}},Zo={narrow:{am:"a",pm:"p",midnight:"mi",noon:"n",morning:"in the morning",afternoon:"in the afternoon",evening:"in the evening",night:"at night"},abbreviated:{am:"AM",pm:"PM",midnight:"midnight",noon:"noon",morning:"in the morning",afternoon:"in the afternoon",evening:"in the evening",night:"at night"},wide:{am:"a.m.",pm:"p.m.",midnight:"midnight",noon:"noon",morning:"in the morning",afternoon:"in the afternoon",evening:"in the evening",night:"at night"}},ei=function(t,e){var r=Number(t),n=r%100;if(n>20||n<10)switch(n%10){case 1:return r+"st";case 2:return r+"nd";case 3:return r+"rd"}return r+"th"},ti={ordinalNumber:ei,era:ye({values:Qo,defaultWidth:"wide"}),quarter:ye({values:Go,defaultWidth:"wide",argumentCallback:function(t){return t-1}}),month:ye({values:Xo,defaultWidth:"wide"}),day:ye({values:Ko,defaultWidth:"wide"}),dayPeriod:ye({values:Jo,defaultWidth:"wide",formattingValues:Zo,defaultFormattingWidth:"wide"})};const ai=ti;function _e(a){return function(t){var e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},r=e.width,n=r&&a.matchPatterns[r]||a.matchPatterns[a.defaultMatchWidth],s=t.match(n);if(!s)return null;var i=s[0],f=r&&a.parsePatterns[r]||a.parsePatterns[a.defaultParseWidth],g=Array.isArray(f)?ri(f,function(_){return _.test(i)}):ni(f,function(_){return _.test(i)}),u;u=a.valueCallback?a.valueCallback(g):g,u=e.valueCallback?e.valueCallback(u):u;var w=t.slice(i.length);return{value:u,rest:w}}}function ni(a,t){for(var e in a)if(a.hasOwnProperty(e)&&t(a[e]))return e}function ri(a,t){for(var e=0;e<a.length;e++)if(t(a[e]))return e}function si(a){return function(t){var e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},r=t.match(a.matchPattern);if(!r)return null;var n=r[0],s=t.match(a.parsePattern);if(!s)return null;var i=a.valueCallback?a.valueCallback(s[0]):s[0];i=e.valueCallback?e.valueCallback(i):i;var f=t.slice(n.length);return{value:i,rest:f}}}var oi=/^(\d+)(th|st|nd|rd)?/i,ii=/\d+/i,li={narrow:/^(b|a)/i,abbreviated:/^(b\.?\s?c\.?|b\.?\s?c\.?\s?e\.?|a\.?\s?d\.?|c\.?\s?e\.?)/i,wide:/^(before christ|before common era|anno domini|common era)/i},ui={any:[/^b/i,/^(a|c)/i]},di={narrow:/^[1234]/i,abbreviated:/^q[1234]/i,wide:/^[1234](th|st|nd|rd)? quarter/i},ci={any:[/1/i,/2/i,/3/i,/4/i]},mi={narrow:/^[jfmasond]/i,abbreviated:/^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i,wide:/^(january|february|march|april|may|june|july|august|september|october|november|december)/i},gi={narrow:[/^j/i,/^f/i,/^m/i,/^a/i,/^m/i,/^j/i,/^j/i,/^a/i,/^s/i,/^o/i,/^n/i,/^d/i],any:[/^ja/i,/^f/i,/^mar/i,/^ap/i,/^may/i,/^jun/i,/^jul/i,/^au/i,/^s/i,/^o/i,/^n/i,/^d/i]},hi={narrow:/^[smtwf]/i,short:/^(su|mo|tu|we|th|fr|sa)/i,abbreviated:/^(sun|mon|tue|wed|thu|fri|sat)/i,wide:/^(sunday|monday|tuesday|wednesday|thursday|friday|saturday)/i},vi={narrow:[/^s/i,/^m/i,/^t/i,/^w/i,/^t/i,/^f/i,/^s/i],any:[/^su/i,/^m/i,/^tu/i,/^w/i,/^th/i,/^f/i,/^sa/i]},fi={narrow:/^(a|p|mi|n|(in the|at) (morning|afternoon|evening|night))/i,any:/^([ap]\.?\s?m\.?|midnight|noon|(in the|at) (morning|afternoon|evening|night))/i},pi={any:{am:/^a/i,pm:/^p/i,midnight:/^mi/i,noon:/^no/i,morning:/morning/i,afternoon:/afternoon/i,evening:/evening/i,night:/night/i}},yi={ordinalNumber:si({matchPattern:oi,parsePattern:ii,valueCallback:function(t){return parseInt(t,10)}}),era:_e({matchPatterns:li,defaultMatchWidth:"wide",parsePatterns:ui,defaultParseWidth:"any"}),quarter:_e({matchPatterns:di,defaultMatchWidth:"wide",parsePatterns:ci,defaultParseWidth:"any",valueCallback:function(t){return t+1}}),month:_e({matchPatterns:mi,defaultMatchWidth:"wide",parsePatterns:gi,defaultParseWidth:"any"}),day:_e({matchPatterns:hi,defaultMatchWidth:"wide",parsePatterns:vi,defaultParseWidth:"any"}),dayPeriod:_e({matchPatterns:fi,defaultMatchWidth:"any",parsePatterns:pi,defaultParseWidth:"any"})};const _i=yi;var bi={code:"en-US",formatDistance:No,formatLong:zo,formatRelative:jo,localize:ai,match:_i,options:{weekStartsOn:0,firstWeekContainsDate:1}};const wi=bi;var Ci=/[yYQqMLwIdDecihHKkms]o|(\w)\1*|''|'(''|[^'])+('|$)|./g,Mi=/P+p+|P+|p+|''|'(''|[^'])+('|$)|./g,$i=/^'([^]*?)'?$/,Ti=/''/g,ki=/[a-zA-Z]/;function Ui(a,t,e){var r,n,s,i,f,g,u,w,_,c,v,h,o,$,L,R,H,N;G(2,arguments);var b=String(t),C=Se(),p=(r=(n=e==null?void 0:e.locale)!==null&&n!==void 0?n:C.locale)!==null&&r!==void 0?r:wi,I=me((s=(i=(f=(g=e==null?void 0:e.firstWeekContainsDate)!==null&&g!==void 0?g:e==null||(u=e.locale)===null||u===void 0||(w=u.options)===null||w===void 0?void 0:w.firstWeekContainsDate)!==null&&f!==void 0?f:C.firstWeekContainsDate)!==null&&i!==void 0?i:(_=C.locale)===null||_===void 0||(c=_.options)===null||c===void 0?void 0:c.firstWeekContainsDate)!==null&&s!==void 0?s:1);if(!(I>=1&&I<=7))throw new RangeError("firstWeekContainsDate must be between 1 and 7 inclusively");var x=me((v=(h=(o=($=e==null?void 0:e.weekStartsOn)!==null&&$!==void 0?$:e==null||(L=e.locale)===null||L===void 0||(R=L.options)===null||R===void 0?void 0:R.weekStartsOn)!==null&&o!==void 0?o:C.weekStartsOn)!==null&&h!==void 0?h:(H=C.locale)===null||H===void 0||(N=H.options)===null||N===void 0?void 0:N.weekStartsOn)!==null&&v!==void 0?v:0);if(!(x>=0&&x<=6))throw new RangeError("weekStartsOn must be between 0 and 6 inclusively");if(!p.localize)throw new RangeError("locale must contain localize property");if(!p.formatLong)throw new RangeError("locale must contain formatLong property");var V=ae(a);if(!ho(V))throw new RangeError("Invalid time value");var j=Eo(V),U=fo(V,j),d={firstWeekContainsDate:I,weekStartsOn:x,locale:p,_originalDate:V},T=b.match(Mi).map(function(D){var E=D[0];if(E==="p"||E==="P"){var W=So[E];return W(D,p.formatLong)}return D}).join("").match(Ci).map(function(D){if(D==="''")return"'";var E=D[0];if(E==="'")return Di(D);var W=Do[E];if(W)return!(e!=null&&e.useAdditionalWeekYearTokens)&&Ao(D)&&gt(D,t,String(a)),!(e!=null&&e.useAdditionalDayOfYearTokens)&&xo(D)&&gt(D,t,String(a)),W(U,D,p.localize,d);if(E.match(ki))throw new RangeError("Format string contains an unescaped latin alphabet character `"+E+"`");return D}).join("");return T}function Di(a){var t=a.match($i);return t?t[1].replace(Ti,"'"):a}const Li=Ge(Ui,2),Ii={class:"seventv-user-card-container"},Si={class:"seventv-user-card-header"},Ei={class:"seventv-user-card-menuactions"},Pi={class:"seventv-user-card-avatar"},Oi=["src"],xi=["src"],Ai={class:"seventv-user-card-usertag-container"},Ri=["href"],Bi=["data-seventv-paint-id"],Ni={class:"seventv-user-card-badges"},Vi={class:"seventv-user-card-interactive"},Fi={class:"seventv-user-card-metrics"},Hi={key:0},Wi={key:1},zi={key:2},Yi={key:3},qi=["show-tabs"],ji=Y({__name:"UserCard",props:{target:{}},emits:["close","mount-handle"],setup(a,{emit:t}){const e=a,r=t,n=ue(),s=aa(n),{identity:i}=Yt(qt()),f=Ye(e.target.id),g=Ie(n),u=ba(n),w=Le(),{t:_}=ze(),c=S(),v=S(),h=S(null),o=ce({activeTab:"messages",canActorAccessLogs:!1,ban:null,paint:null,targetUser:{id:e.target.id,username:e.target.username,displayName:e.target.displayName,intl:e.target.intl,color:e.target.color,bannerURL:"",avatarURL:"",createdAt:"",isModerator:!1,badges:[],relationship:{followedAt:"",subscription:{isSubscribed:!1,tier:"",months:0}}},stream:{live:!1,game:"",viewCount:0},messageCursors:new WeakMap,timelines:{messages:{},warnings:{},bans:{},timeouts:{},comments:{}},count:{messages:0,warnings:0,bans:0,timeouts:0,comments:0}}),$=te(()=>{var D;if(!o.targetUser.username)return;const d=qe("avatars").value;if(!((D=d==null?void 0:d.instance)!=null&&D.avatars))return;const T=d.instance.avatars[o.targetUser.username];return T==null?void 0:T.data.user.avatar_url});function L(){return o.timelines[o.activeTab]}async function R(d){var W;if(!o.targetUser||!w.value||o.activeTab!=="messages")return[];const T=d?o.messageCursors.get(d):void 0,D=await w.value.query({query:Ma,variables:{channelID:n.id,senderID:o.targetUser.id,cursor:T}}).catch(z=>Promise.reject(z));if(!D||(W=D.errors)!=null&&W.length||!Array.isArray(D.data.logs.messages.edges))return[];const E=[];for(const z of D.data.logs.messages.edges){if(!z.node)continue;const K=Ne(z.node);E.push(K),o.messageCursors.set(K,z.cursor)}return E}async function H(){var W;if(!o.targetUser||!w.value)return;const d=await w.value.query({query:Ca,variables:{channelLogin:n.username,channelID:n.id,targetID:o.targetUser.id}}).catch(z=>Promise.reject(z));if(!d||(W=d.errors)!=null&&W.length||!d.data.channelUser)return;o.count.messages=d.data.viewerCardModLogs.messages.count??0,o.count.warnings=d.data.viewerCardModLogs.warnings.count??0,o.count.bans=d.data.viewerCardModLogs.bans.count??0,o.count.timeouts=d.data.viewerCardModLogs.timeouts.count??0,o.count.comments=d.data.viewerCardModLogs.comments.edges.length??0,o.ban=d.data.banStatus;const T=d.data.viewerCardModLogs.timeouts.edges,D=d.data.viewerCardModLogs.bans.edges,E=d.data.viewerCardModLogs.warnings.edges;for(const[z,K]of[["timeouts",T],["bans",D],["warnings",E]]){const ne=[];for(const se of K){const J=new Ze(se.node.id).setComponent(mo,{text:se.node.localizedLabel.localizedStringFragments.map(ge=>"text"in ge.token?ge.token.text:ge.token.login).join("")});J.setTimestamp(Date.parse(se.node.timestamp)),ne.push(J)}p(ne,z)}for(const z of d.data.viewerCardModLogs.comments.edges)N(z.node)}function N(d){const T=new Ze(d.id);T.setAuthor({id:d.author.id,username:d.author.login,displayName:d.author.displayName,color:d.author.chatColor,intl:d.author.login!==d.author.displayName.toLowerCase()}),T.setTimestamp(Date.parse(d.timestamp)),T.body=d.text,p([T],"comments")}function b(){if(!c.value||!c.value.container||c.value.container.scrollTop>0)return;const T=C(new Date(Math.min(...Object.keys(o.timelines.messages).map(W=>Date.parse(W)||1/0))));if(!T)return;const D=o.timelines.messages[T];if(!D)return;const E=D[0];E&&(I(1),R(E).then(W=>{W.length&&p(W)}).catch(W=>{ie.error("Failed to fetch more messages",W)}))}function C(d){return`${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`}function p(d,T="messages"){const D=o.timelines[T],E=s.find(z=>!!z.author&&z.author.id===e.target.id,!0),W=new Set(E.map(z=>z.id));for(const z of d){if(!z.timestamp)continue;const K=W.has(z.id)?"LIVE":C(new Date(z.timestamp));if(!D[K])D[K]=[];else if(D[K].find(ne=>ne.id===z.id))continue;D[K].unshift(z),D[K].sort((ne,se)=>ne.timestamp-se.timestamp)}}function I(d){!c.value||!c.value.container||c.value.container.scrollTo({top:d})}function x(d){!o.targetUser.username||!g.openViewerCard(d,o.targetUser.username,"")||r("close")}function V(){if(!o.targetUser.username)return;let d=!1;o.targetUser.username in u.getAllUsernameHighlights()?(u.remove(o.targetUser.username),d=!0):(u.define(o.targetUser.username,{pattern:o.targetUser.username,label:"Messages by "+o.targetUser.username,color:"#8803fc",flashTitle:!1,username:!0},!0),d=!0),d&&u.save()}function j(){return window.location.origin+"/"+e.target.username}function U(d){return d?Li("PPP")(new Date(d)):""}return ve(async()=>{if(w.value){w.value.query({query:wa,variables:{channelID:n.id,channelIDStr:n.id,channelLogin:n.username,targetLogin:e.target.username,withStandardGifting:!1,isViewerBadgeCollectionEnabled:!0}}).then(async d=>{var T,D,E,W,z,K,ne,se;if(d.data.channel&&(o.canActorAccessLogs=((T=d.data.channel.moderationSettings)==null?void 0:T.canAccessViewerCardModLogs)??!1),d.data.targetUser){if(o.targetUser.id=d.data.targetUser.id,o.targetUser.username=d.data.targetUser.login,o.targetUser.displayName=d.data.targetUser.displayName,o.targetUser.intl=d.data.targetUser.login!==d.data.targetUser.displayName.toLowerCase(),o.targetUser.avatarURL=d.data.targetUser.profileImageURL,o.targetUser.bannerURL=d.data.targetUser.bannerImageURL??"",o.targetUser.color=d.data.targetUser.chatColor??e.target.color,o.targetUser.relationship.followedAt=U((D=d.data.targetUser.relationship)==null?void 0:D.followedAt),o.targetUser.createdAt=U(d.data.targetUser.createdAt),o.targetUser.relationship.subscription.months=((W=(E=d.data.targetUser.relationship)==null?void 0:E.cumulativeTenure)==null?void 0:W.months)??0,(z=d.data.targetUser.relationship)!=null&&z.subscriptionBenefit&&(o.targetUser.relationship.subscription.isSubscribed=!0,o.targetUser.relationship.subscription.tier=(K=d.data.targetUser.relationship)==null?void 0:K.subscriptionBenefit.tier),d.data.targetUser.stream&&(o.stream.live=!0,o.stream.game=((ne=d.data.targetUser.stream.game)==null?void 0:ne.displayName)??"",o.stream.viewCount=d.data.targetUser.stream.viewersCount),o.targetUser.badges.length=0,o.targetUser.isModerator=d.data.targetUser.isModerator||d.data.targetUser.id===n.id,d.data.channelViewer&&((se=d.data.channelViewer.earnedBadges)!=null&&se.length))for(let J=0;J<d.data.channelViewer.earnedBadges.length;J++){const ge=Xt(d.data.channelViewer.earnedBadges[J]);ge&&(o.targetUser.badges[J]=ge)}for(const J of f.badges.values())o.targetUser.badges.push(J)}o.targetUser&&(o.canActorAccessLogs||i.value&&o.targetUser.id===i.value.id)&&(p(await R().catch(J=>ie.error("failed to fetch message logs",J))??[]),H().catch(J=>ie.error("failed to fetch moderator data",J)))}).catch(d=>ie.error("failed to query user card",d));for(const d of f.paints.values()){o.paint=d;break}}}),le(()=>[o.targetUser.bannerURL,o.targetUser.color],([d,T])=>{h.value&&(h.value.style.setProperty("--seventv-user-card-banner-url",`url(${d})`),h.value.style.setProperty("--seventv-user-card-color",T))}),vt(async()=>{v.value&&r("mount-handle",v.value),p(s.find(d=>!!d.author&&d.author.id===e.target.id,!0)),De(()=>{!c.value||!c.value.container||I(c.value.container.scrollHeight)})}),(d,T)=>{const D=pe("tooltip");return l(),m("main",Ii,[y("div",{ref_key:"cardRef",ref:h,class:"seventv-user-card"},[y("div",Si,[y("div",{ref_key:"dragHandle",ref:v,class:"seventv-user-card-identity"},[y("div",Ei,[o.targetUser.username in M(u).getAllUsernameHighlights()?Q((l(),F(Aa,{key:0,onClick:V},null,512)),[[D,M(_)("user_card.stop_highlight")]]):Q((l(),F(Ia,{key:1,onClick:V},null,512)),[[D,M(_)("user_card.highlight")]]),Q(O(jt,{onClick:x},null,512),[[D,M(_)("user_card.native")]]),O(Qt,{class:"close-button",onClick:T[0]||(T[0]=E=>r("close"))})]),y("div",Pi,[$.value?(l(),m("img",{key:0,src:$.value},null,8,Oi)):o.targetUser.avatarURL?(l(),m("img",{key:1,src:o.targetUser.avatarURL},null,8,xi)):k("",!0)]),y("div",Ai,[y("a",{href:j(),target:"_blank",class:"seventv-user-card-usertag"},[O(we,{user:o.targetUser,"hide-badges":!0,clickable:!1},null,8,["user"])],8,Ri)]),o.paint?(l(),m("span",{key:0,class:"seventv-user-card-paint seventv-painted-content seventv-paint","data-seventv-paint-id":o.paint.id},[y("p",null,B(o.paint.data.name),1)],8,Bi)):k("",!0),y("div",Ni,[(l(!0),m(q,null,re(o.targetUser.badges,E=>(l(),F(Me,{key:E.id,badge:E,alt:E.data.tooltip,type:"app"},null,8,["badge","alt"]))),128))])],512),y("div",Vi,[y("div",Fi,[o.targetUser.createdAt?(l(),m("p",Hi,[O(Ha),Z(" "+B(M(_)("user_card.account_created_date",{date:o.targetUser.createdAt})),1)])):k("",!0),o.targetUser.relationship.followedAt?(l(),m("p",Wi,[O(Qa),Z(" "+B(M(_)("user_card.following_since_date",{date:o.targetUser.relationship.followedAt})),1)])):k("",!0),o.targetUser.relationship.subscription.isSubscribed?(l(),m("p",zi,[O(et),Z(" "+B(o.targetUser.relationship.subscription.months?`${M(_)("user_card.subscription_tier",{tier:o.targetUser.relationship.subscription.tier[0]})} -
									  ${M(_)("user_card.subscription_length",{length:o.targetUser.relationship.subscription.months})}`:`${M(_)("user_card.hidden_subscription_status")}`),1)])):o.targetUser.relationship.subscription.months?(l(),m("p",Yi,[O(et),Z(" "+B(M(_)("user_card.previously_subscription_length",{length:o.targetUser.relationship.subscription.months})),1)])):k("",!0)]),O(Ja),M(n).actor.roles.has("MODERATOR")&&!o.targetUser.isModerator||M(n).actor.roles.has("BROADCASTER")?(l(),F(ro,{key:0,target:o.targetUser,ban:o.ban,"is-moderator":o.targetUser.isModerator,onVictimBanned:T[1]||(T[1]=E=>o.ban=E),onVictimUnbanned:T[2]||(T[2]=E=>o.ban=null),onVictimModded:T[3]||(T[3]=E=>o.targetUser.isModerator=!0),onVictimUnmodded:T[4]||(T[4]=E=>o.targetUser.isModerator=!1)},null,8,["target","ban","is-moderator"])):k("",!0)])]),y("div",{class:"seventv-user-card-data","show-tabs":M(n).actor.roles.has("MODERATOR")},[M(n).actor.roles.has("MODERATOR")?(l(),F(lo,{key:0,"active-tab":o.activeTab,"message-count":o.count.messages,"warning-count":o.count.warnings,"ban-count":o.count.bans,"timeout-count":o.count.timeouts,"comment-count":o.count.comments,onSwitch:T[5]||(T[5]=E=>o.activeTab=E)},null,8,["active-tab","message-count","warning-count","ban-count","timeout-count","comment-count"])):k("",!0),O($t,{ref_key:"scroller",ref:c,onContainerScroll:b},{default:fe(()=>[O(As,{"active-tab":o.activeTab,target:o.targetUser,timeline:L(),scroller:c.value,onAddModComment:N},null,8,["active-tab","target","timeline","scroller"])]),_:1},512)],8,qi)],512)])}}}),Qi=P(ji,[["__scopeId","data-v-ae45b420"]]),Gi={key:0,class:"seventv-chat-user-badge-list"},Xi={key:0},Ki={key:1},Ji=Y({__name:"UserTag",props:{user:{},sourceData:{},msgId:{},isMention:{type:Boolean},hideAt:{type:Boolean},hideBadges:{type:Boolean},clickable:{type:Boolean,default:!0},badges:{}},emits:["open-native-card"],setup(a,{emit:t}){const e=a,r=t,n=ue(),s=Tt(n),i=Ye(e.user.id),f=X("vanity.nametag_paints"),g=X("vanity.7tv_Badges"),u=X("chat.user_card"),w=S([]),_=_t(s,"twitchBadgeSets"),c=X("chat.colored_mentions"),v=S(),h=S(!1),o=S(),$=S(null),L=S([]),R=te(()=>!f.value||!$.value?!1:e.isMention?c.value===2:!0),H=te(()=>!e.isMention||c.value===1);function N(p){if(e.clickable){if(!u.value){r("open-native-card",p);return}h.value=!h.value}}ve(()=>{var p;if(e.badges&&_.value&&!w.value.length)for(const[I,x]of Object.entries(e.badges)){const V=I,j=x;for(const U of[((p=e.sourceData)==null?void 0:p.badges.channelsBySet)??_.value.channelsBySet,_.value.globalsBySet]){if(!U)continue;const d=U.get(V);if(!d)continue;const T=d.get(j);if(T){w.value.push(T);break}}}});const b=Date.now(),C=le([()=>i.paints,()=>i.badges],([p,I])=>{if(e.msgId&&e.user.lastMsgId&&e.msgId!==e.user.lastMsgId&&Date.now()-b>5e3){De(()=>C());return}$.value=p&&p.size?p.values().next().value:null,L.value=I&&I.size?[...I.values()]:[]},{immediate:!0});return(p,I)=>{var j;const x=pe("cosmetic-paint"),V=pe("tooltip");return l(),m(q,null,[p.user&&p.user.displayName?(l(),m("div",{key:0,ref_key:"tagRef",ref:v,class:"seventv-chat-user",style:$e(H.value?{color:p.user.color}:{})},[!p.hideBadges&&(w.value.length&&((j=_.value)!=null&&j.count)||M(i).badges.size||p.sourceData)?(l(),m("span",Gi,[p.sourceData?(l(),F(Me,{key:p.sourceData.login,badge:p.sourceData,alt:p.sourceData.displayName,type:"picture"},null,8,["badge","alt"])):k("",!0),(l(!0),m(q,null,re(w.value,U=>(l(),F(Me,{key:U.id,badge:U,alt:U.title,type:"twitch",onClick:I[0]||(I[0]=d=>N(d))},null,8,["badge","alt"]))),128)),M(g)?(l(!0),m(q,{key:1},re(L.value,U=>(l(),F(Me,{key:U.id,badge:U,alt:U.data.tooltip,type:"app"},null,8,["badge","alt"]))),128)):k("",!0)])):k("",!0),Q((l(),m("span",{class:"seventv-chat-user-username",onClick:I[1]||(I[1]=U=>N(U))},[Q((l(),m("span",null,[p.isMention&&!p.hideAt?(l(),m("span",Xi,"@")):k("",!0),y("span",null,B(p.user.displayName),1),p.user.intl?(l(),m("span",Ki," ("+B(p.user.username)+")",1)):k("",!0)])),[[x,R.value?$.value.id:null]])])),[[V,R.value?`Paint: ${$.value.data.name}`:""]])],4)):k("",!0),h.value&&v.value?(l(),F(Re,{key:1,to:"#seventv-float-context"},[O(ma,{class:"seventv-user-card-float",handle:o.value,"initial-anchor":v.value,"initial-middleware":[M(Ae)({mainAxis:!0,crossAxis:!0}),M(Nt)()],once:!0},{default:fe(()=>[O(Qi,{target:e.user,onClose:I[2]||(I[2]=U=>h.value=!1),onMountHandle:I[3]||(I[3]=U=>o.value=U)},null,8,["target"])]),_:1},8,["handle","initial-anchor","initial-middleware"])])):k("",!0)],64)}}}),we=P(Ji,[["__scopeId","data-v-c9ed9f71"]]);export{Vn as A,Me as B,bl as I,Fe as U,Xs as W,ks as _,Za as a,en as b,je as c,ba as d,mo as e,Ie as f,ae as g,me as h,Te as i,Eo as j,Ge as k,we as l,wl as m,An as n,wi as o,Se as p,G as r,it as t,Tt as u};
